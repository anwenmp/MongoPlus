# 本次真实执行与解析结果

环境：JDK 17.0.20.1、MongoDB 9.0.4、Driver 5.13.0；使用现有测试库与本次随机前缀集合。共46个自有集合，清理失败/残留 0。

原始[结果与命令](../validation/live-20261111T110905Z-361f47/results.json)、[环境](../validation/live-20261111T110905Z-361f47/environment.json)、[夹具](../validation/LiveValidation.java)。只计本轮，不把历史或旧README结果累加。

每个聚合用例比较完整实发pipeline与独立客户端原生aggregate的完整结果集；未定义顺序的结果按完整Document规范排序后比较。其他用例检查明确的原始文档/独立客户端可见性。注解解析无数据库命令，不计LIVE。

| 用例 | 真实API | 结果 | 证据 |
|---|---|---|---|
| match-Bson-body | `LambdaAggregateWrapper.match(Bson)` | LIVE_PASS | commands=4 |
| project-Bson-body | `LambdaAggregateWrapper.project(Bson)` | LIVE_PASS | commands=4 |
| addFields-Bson-body | `LambdaAggregateWrapper.addFields(Bson)` | LIVE_PASS | commands=4 |
| set-Bson-body | `LambdaAggregateWrapper.set(Bson)` | LIVE_PASS | commands=4 |
| bucket-Bson-body | `LambdaAggregateWrapper.bucket(Bson)` | LIVE_PASS | commands=4 |
| bucketAuto-Bson-body | `LambdaAggregateWrapper.bucketAuto(Bson)` | LIVE_PASS | commands=4 |
| sort-Bson-full-stage | `LambdaAggregateWrapper.sort(Bson)` | LIVE_PASS | commands=4 |
| sortSpecification-body | `Aggregate.sortSpecification(Bson)` | LIVE_PASS | commands=4 |
| sort-String | `LambdaAggregateWrapper.sort(String,Integer)` | LIVE_PASS | commands=4 |
| group-Bson-full-stage | `LambdaAggregateWrapper.group(Bson)` | LIVE_PASS | commands=4 |
| group-accumulator | `LambdaAggregateWrapper.group(Object,BsonField...)` | LIVE_PASS | commands=4 |
| facet-Bson-full-stage | `LambdaAggregateWrapper.facet(Bson)` | LIVE_PASS | commands=4 |
| unwind-Bson-full-stage | `LambdaAggregateWrapper.unwind(Bson)` | LIVE_PASS | commands=4 |
| replaceRoot-Bson-full-stage | `LambdaAggregateWrapper.replaceRoot(Bson) [explicit Bson cast]` | LIVE_PASS | commands=4 |
| replaceRoot-Document-expression | `LambdaAggregateWrapper.replaceRoot(Document)` | LIVE_PASS | commands=4 |
| replaceWith-Bson-full-stage | `LambdaAggregateWrapper.replaceWith(Bson) [explicit Bson cast]` | LIVE_PASS | commands=4 |
| replaceWith-Document-expression | `LambdaAggregateWrapper.replaceWith(Document)` | LIVE_PASS | commands=4 |
| sample-Bson-full-stage | `LambdaAggregateWrapper.sample(Bson)` | LIVE_PASS | commands=4 |
| window-Bson-full-stage | `LambdaAggregateWrapper.setWindowFields(Bson)` | LIVE_PASS | commands=4 |
| densify-Bson-full-stage | `LambdaAggregateWrapper.densify(Bson)` | LIVE_PASS | commands=4 |
| fill-Bson-full-stage | `LambdaAggregateWrapper.fill(Bson)` | LIVE_PASS | commands=4 |
| unset-Bson-full-stage | `LambdaAggregateWrapper.unset(Bson)` | LIVE_PASS | commands=4 |
| skip-limit | `LambdaAggregateWrapper.skip(int)/limit(int)` | LIVE_PASS | commands=4 |
| sortByCount | `LambdaAggregateWrapper.sortByCount(String)` | LIVE_PASS | commands=4 |
| lookup-Bson-full-stage | `LambdaAggregateWrapper.lookup(Bson)` | LIVE_PASS | commands=4 |
| lookup-four-String | `LambdaAggregateWrapper.lookup(String,String,String,String)` | LIVE_PASS | commands=4 |
| unionWith-Bson-full-stage | `LambdaAggregateWrapper.unionWith(Bson)` | LIVE_PASS | commands=4 |
| query-same-array-element | `BaseMapper.list + QueryWrapper.elemMatch(String,Wrapper)` | LIVE_PASS | commands=4 |
| regex-explicit-case-sensitive | `QueryWrapper.regex(String,Object,RegexOptions)` | LIVE_PASS | commands=3 |
| projection-sort | `QueryWrapper.projectDisplay + orderByDesc` | LIVE_PASS | commands=4 |
| update-CAS-single | `BaseMapper.updateOne(UpdateWrapper)` | LIVE_PASS | commands=9 |
| pull-value | `UpdateWrapper.pull` | LIVE_PASS | commands=8 |
| pull-wrapper-custom | `UpdateWrapper.pull` | LIVE_PASS | commands=8 |
| mapped-annotations-roundtrip | `BaseMapper.save/list + mapping annotations` | LIVE_PASS | commands=4 |
| field-chain-current-value | `FieldHandlerChain + Mapper.save` | LIVE_PASS | commands=2 |
| fieldbind-explicit-registration | `HandlerCache.addReadHandler(new FieldBindHandler)` | LIVE_PASS | commands=2 |
| fieldbind-camel-target | `FieldBind.target(statusName) + ReadHandler` | CONTRACT_UNRESOLVED | commands=2；fieldBind target field not found |
| ordinary-index-unique | `Resolver + BaseMapper.createIndexes` | LIVE_PASS | commands=4 |
| transaction-commit | `MongoTransactionalManager + Mapper` | LIVE_PASS | commands=4 |
| transaction-rollback | `MongoTransactionalManager + Mapper` | LIVE_PASS | commands=3 |
| deployment-probe-search | `Driver listSearchIndexes prerequisite` | NOT_RUN | commands=2；serverCode=31082 |
| deployment-probe-vectorSearch | `Driver listSearchIndexes prerequisite` | NOT_RUN | commands=2；serverCode=31082 |
| annotation-parser-MongoCompoundIndex | `Resolver.resolve(MongoCompoundIndexExample)` | PARSE_PASS | commands=0 |
| annotation-parser-MongoCompoundIndexes | `Resolver.resolve(MongoCompoundIndexesExample)` | PARSE_PASS | commands=0 |
| annotation-parser-MongoGeoIndex | `Resolver.resolve(MongoGeoIndexExample)` | PARSE_PASS | commands=0 |
| annotation-parser-MongoHashIndex | `Resolver.resolve(MongoHashIndexExample)` | PARSE_PASS | commands=0 |
| annotation-parser-MongoIndex | `Resolver.resolve(MongoIndexExample)` | PARSE_PASS | commands=0 |
| annotation-parser-MongoIndexDs | `Resolver.resolve(MongoIndexDsExample)` | PARSE_PASS | commands=0 |
| annotation-parser-MongoTextIndex | `Resolver.resolve(MongoTextIndexExample)` | PARSE_PASS | commands=0 |
| annotation-parser-MongoSearchIndex | `Resolver.resolve(MongoSearchIndexExample)` | PARSE_PASS | commands=0 |
| annotation-parser-MongoSearchIndexes | `Resolver.resolve(MongoSearchIndexesExample)` | PARSE_PASS | commands=0 |
| annotation-parser-MongoSearchField | `Resolver.resolve(MongoSearchFieldExample)` | PARSE_PASS | commands=0 |
| annotation-parser-MongoSearchFields | `Resolver.resolve(MongoSearchFieldsExample)` | PARSE_PASS | commands=0 |
| annotation-parser-MongoSearchSort | `Resolver.resolve(MongoSearchSortExample)` | PARSE_PASS | commands=0 |
| annotation-parser-MongoSearchSorts | `Resolver.resolve(MongoSearchSortsExample)` | PARSE_PASS | commands=0 |
| annotation-parser-MongoSearchStoredSource | `Resolver.resolve(MongoSearchStoredSourceExample)` | PARSE_PASS | commands=0 |
| annotation-parser-MongoSearchSynonym | `Resolver.resolve(MongoSearchSynonymExample)` | PARSE_PASS | commands=0 |
| annotation-parser-MongoVectorIndex | `Resolver.resolve(MongoVectorIndexExample)` | PARSE_PASS | commands=0 |
| annotation-parser-MongoVectorIndexes | `Resolver.resolve(MongoVectorIndexesExample)` | PARSE_PASS | commands=0 |
| annotation-parser-MongoVectorField | `Resolver.resolve(MongoVectorFieldExample)` | PARSE_PASS | commands=0 |
| annotation-parser-MongoVectorFields | `Resolver.resolve(MongoVectorFieldsExample)` | PARSE_PASS | commands=0 |
| annotation-parser-MongoVectorHnswOptions | `Resolver.resolve(MongoVectorHnswOptionsExample)` | PARSE_PASS | commands=0 |
| annotation-parser-MongoVectorStoredSource | `Resolver.resolve(MongoVectorStoredSourceExample)` | PARSE_PASS | commands=0 |

## 已执行重载的参数与原生对照

match/project/addFields/set/bucket/bucketAuto的Bson输入是参数体；sort/lookup/facet/group/unwind/unionWith/window/densify/fill/unset的显式Bson输入是完整阶段，实发命令与原生pipeline逐项一致。replaceRoot/replaceWith额外分别执行Bson完整阶段与Document表达式重载，具体输入在夹具，命令/完整结果在JSON的case.results和case.commands。

pull(String,Object)的第一个参数是目标数组物理名，第二个是元素条件体；pull(Wrapper)测试使用custom({items:条件体})，二者与原生$pull结果一致。eq("items",条件体)首轮生成$eq包裹，未实现多条件元素谓词，不能把该写法当作正确示例。

字段测试保存后由独立客户端核对重命名、null、忽略字段、Base64存储和枚举数字；回读确认脱敏、解密及ExtraFields。FieldBind显式注册在label目标上通过；target=statusName在默认命名配置下抛出目标字段不存在，保留CONTRACT_UNRESOLVED。事务测试经MongoPlus管理器和Mapper，独立客户端核对提交前/提交后/回滚后的可见性；未替代Spring/Solon代理验证。

## 首轮失败与修正记录

保留validation/live-*历史目录。首轮混合统计31 PASS/27 UNVERIFIED不作最终通过率：反射夹具改为public类及公开无参构造器；replaceRoot/replaceWith完整Document选择Document表达式重载改为显式Bson；pull使用合法元素谓词重载并增加custom-wrapper对照。旧失败未删除、生产源码未修改。新的camel target探索仍未闭合，不改断言制造成功。

Search/Vector管理前置探测都收到31082，相关索引DDL及搜索查询运行记NOT_RUN。21个索引注解示例只通过Resolver解析与模型检查，不冒充Search服务端验证。
