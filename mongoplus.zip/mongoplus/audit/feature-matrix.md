# 功能覆盖矩阵

101个能力/边界检查项均有专题；不是101个全重载运行通过。LIVE_PARTIAL与PARSE_PASS_ONLY仍保留未运行部分。原始用例见[实测报告](runtime-results.md)，未运行列表见[总报告](coverage-report.md)。

| 功能 | 主要公开 API | 文档位置 | 验证状态 |
|---|---|---|---|
| C001 接入Core与独立Java | `Configuration` | [专题](../references/integration.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C002 Spring Boot 3接入与Mapper扫描 | `MongoMapperScan`, `MongoMapperFactoryBean` | [专题](../references/integration.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C003 Spring Boot 4接入与差异 | `MongoMapperScan`, `MongoPlusAutoConfiguration` | [专题](../references/integration.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C004 Solon接入与代理注入 | `XPluginAuto`, `CollectionScanner` | [专题](../references/integration.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C005 BOM与版本选择 | `com.mongoplus:mongo-plus-bom（Maven版本管理）` | [专题](../references/integration.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C006 实体Mapper访问层 | `MongoMapper`, `MongoMapperImpl` | [专题](../references/crud.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C007 无绑定实体BaseMapper | `BaseMapper`, `Mapper`, `SuperMapper` | [专题](../references/crud.md) | SOURCE_VERIFIED; LIVE_PARTIAL；query-same-array-element, mapped-annotations-roundtrip |
| C008 Repository与Service | `IRepository`, `RepositoryImpl`, `IService`, `ServiceImpl` | [专题](../references/crud.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C009 单条保存与ID回写 | `MongoMapper#save` | [专题](../references/crud.md) | SOURCE_VERIFIED; LIVE_PARTIAL；mapped-annotations-roundtrip |
| C010 批量保存与saveOrUpdate | `MongoMapper#saveBatch`, `MongoMapper#saveOrUpdate` | [专题](../references/crud.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C011 实体更新与按ID批改 | `MongoMapper#updateById`, `MongoMapper#updateBatchByIds` | [专题](../references/crud.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C012 单条与批量删除 | `BaseMapper#remove`, `BaseMapper#removeOne` | [专题](../references/crud.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C013 单条读取与存在性 | `MongoMapper#one`, `MongoMapper#exist` | [专题](../references/crud.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C014 分页与计数 | `PageParam`, `PageResult`, `BaseMapper#page`, `BaseMapper#recentPageCount` | [专题](../references/crud.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C015 批量WriteModel操作 | `BaseMapper#bulkWrite` | [专题](../references/crud.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C016 原生Document与BSON命令 | `SuperMapper#command`, `BaseMapper#queryCommand` | [专题](../references/crud.md) | SOURCE_VERIFIED; LIVE_PARTIAL；query-same-array-element |
| C017 distinct与replaceOne选型 | `com.mongodb.client.MongoCollection.distinct / replaceOne（Driver边界）` | [专题](../references/driver-interop.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C018 findOneAndRemove与返回删除前文档 | `BaseMapper#findOneAndRemove` | [专题](../references/crud.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C019 查询Wrapper与链式终结 | `QueryWrapper`, `LambdaQueryChainWrapper`, `ChainWrappers` | [专题](../references/query.md) | SOURCE_VERIFIED; LIVE_PARTIAL；query-same-array-element, regex-explicit-case-sensitive, projection-sort |
| C020 比较范围存在与类型 | `Compare`, `DataType` | [专题](../references/query.md) | SOURCE_VERIFIED; LIVE_PARTIAL；query-same-array-element, projection-sort |
| C021 and-or-nor-not逻辑组合 | `And`, `Or`, `Nor`, `Not` | [专题](../references/query.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C022 嵌套字段与类型安全路径 | `FieldChain`, `FreeFieldChain`, `SFunction` | [专题](../references/query.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C023 数组all-size-elemMatch | `All`, `Size`, `ElemMatch` | [专题](../references/query.md) | SOURCE_VERIFIED; LIVE_PARTIAL；query-same-array-element |
| C024 正则like与大小写 | `Regex`, `Like`, `RegexOptions` | [专题](../references/query.md) | SOURCE_VERIFIED; LIVE_PARTIAL；regex-explicit-case-sensitive |
| C025 投影排序分页选项 | `Projection`, `Ordered`, `QueryParam` | [专题](../references/query.md) | SOURCE_VERIFIED; LIVE_PARTIAL；projection-sort |
| C026 传统文本查询 | `Text`, `TextSearchOptions` | [专题](../references/query.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C027 地理空间查询与模型 | `GeoSpatial`, `GeoNear`, `Coordinate`, `GeoBox`, `GeoCenter` | [专题](../references/query.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C028 位运算与expr-jsonSchema-where | `Bitwise`, `Expr`, `JsonSchema`, `Where`, `Mod` | [专题](../references/query.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C029 原生条件与Filters组合 | `Wrapper`, `Filters` | [专题](../references/query.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C030 更新Wrapper与绑定更新链 | `UpdateWrapper`, `LambdaUpdateChainWrapper` | [专题](../references/update.md) | SOURCE_VERIFIED; LIVE_PARTIAL；update-CAS-single |
| C031 set-unset-rename-currentDate | `Set`, `Unset`, `Rename`, `CurrentDate` | [专题](../references/update.md) | SOURCE_VERIFIED; LIVE_PARTIAL；update-CAS-single |
| C032 inc-mul-min-max与原子更新 | `Inc`, `Mul`, `Min`, `Max` | [专题](../references/update.md) | SOURCE_VERIFIED; LIVE_PARTIAL；update-CAS-single |
| C033 push-addToSet-pop-pull-pullAll | `Push`, `AddToSet`, `Pop`, `Pull`, `PullAll`, `PushOptions` | [专题](../references/update.md) | SOURCE_VERIFIED; LIVE_PARTIAL；pull-value, pull-wrapper-custom |
| C034 updateOne-updateMany与Options | `BaseMapper#updateOne`, `BaseMapper#update` | [专题](../references/update.md) | SOURCE_VERIFIED; LIVE_PARTIAL；update-CAS-single |
| C035 乐观锁版本与重试 | `OptimisticLockerInterceptor`, `Retry`, `UpdateRetryResult` | [专题](../references/update.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C036 空条件更新删除保护 | `BlockAttackInnerListener` | [专题](../references/update.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C037 聚合Wrapper与结果映射 | `AggregateWrapper`, `LambdaAggregateWrapper`, `LambdaAggregateChainWrapper` | [专题](../references/aggregation.md) | SOURCE_VERIFIED; LIVE_PARTIAL；match-Bson-body |
| C038 聚合match-project-sort-skip-limit | `Aggregate#match`, `Aggregate#project`, `Aggregate#sort`, `Aggregate#skip`, `Aggregate#limit` | [专题](../references/aggregation.md) | SOURCE_VERIFIED; LIVE_PARTIAL；match-Bson-body, project-Bson-body, sort-Bson-full-stage, sortSpecification-body, skip-limit |
| C039 聚合addFields-set-unset | `Aggregate#addFields`, `Aggregate#set`, `Aggregate#unset` | [专题](../references/aggregation.md) | SOURCE_VERIFIED; LIVE_PARTIAL；addFields-Bson-body, set-Bson-body, unset-Bson-full-stage |
| C040 聚合lookup关联与let | `Aggregate#lookup`, `Variable` | [专题](../references/aggregation.md) | SOURCE_VERIFIED; LIVE_PARTIAL；lookup-Bson-full-stage, lookup-four-String |
| C041 聚合facet与unionWith | `Aggregate#facet`, `Aggregate#unionWith`, `Facet` | [专题](../references/aggregation.md) | SOURCE_VERIFIED; LIVE_PARTIAL；facet-Bson-full-stage, unionWith-Bson-full-stage |
| C042 聚合graphLookup与unwind | `Aggregate#graphLookup`, `Aggregate#unwind`, `UnwindOption` | [专题](../references/aggregation.md) | SOURCE_VERIFIED; LIVE_PARTIAL；unwind-Bson-full-stage |
| C043 聚合group与累加器 | `Aggregate#group`, `Accumulators` | [专题](../references/aggregation.md) | SOURCE_VERIFIED; LIVE_PARTIAL；group-Bson-full-stage, group-accumulator |
| C044 聚合bucket-bucketAuto-sortByCount-count | `Aggregate#bucket`, `Aggregate#bucketAuto`, `Aggregate#sortByCount`, `Aggregate#count` | [专题](../references/aggregation.md) | SOURCE_VERIFIED; LIVE_PARTIAL；bucket-Bson-body, bucketAuto-Bson-body, sortByCount |
| C045 聚合replaceRoot-replaceWith-sample | `Aggregate#replaceRoot`, `Aggregate#replaceWith`, `Aggregate#sample` | [专题](../references/aggregation.md) | SOURCE_VERIFIED; LIVE_PARTIAL；replaceRoot-Bson-full-stage, replaceRoot-Document-expression, replaceWith-Bson-full-stage, replaceWith-Document-expression, sample-Bson-full-stage |
| C046 聚合out与merge写阶段 | `Aggregate#out`, `Aggregate#merge` | [专题](../references/aggregation.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C047 聚合窗口densify-fill | `Aggregate#setWindowFields`, `Aggregate#densify`, `Aggregate#fill`, `FillField` | [专题](../references/aggregation.md) | SOURCE_VERIFIED; LIVE_PARTIAL；window-Bson-full-stage, densify-Bson-full-stage, fill-Bson-full-stage |
| C048 聚合表达式日期数组数学条件转换 | `AggregateOperator`, `ConditionOperators`, `SimpleExpression` | [专题](../references/expressions.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C049 聚合自定义阶段与执行选项 | `Aggregate#custom`, `AggregateOptions` | [专题](../references/aggregation.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C050 实体元数据与泛型结果 | `TypeInformation`, `FieldInformation`, `TypeReference`, `SimpleTypeHolder` | [专题](../references/mapping.md) | SOURCE_VERIFIED; LIVE_PARTIAL；mapped-annotations-roundtrip |
| C051 ID生成与ObjectId转换 | `IdGenerateHandler`, `IdentifierGenerator`, `IdWorker`, `AutoIdGenerate` | [专题](../references/mapping.md) | SOURCE_VERIFIED; LIVE_PARTIAL；mapped-annotations-roundtrip |
| C052 集合字段命名与null策略 | `AnnotationOperate`, `CollectionNameHandler` | [专题](../references/mapping.md) | SOURCE_VERIFIED; LIVE_PARTIAL；mapped-annotations-roundtrip |
| C053 枚举持久化 | `EnumMappingStrategy`, `EnumConversionStrategy` | [专题](../references/mapping.md) | SOURCE_VERIFIED; LIVE_PARTIAL；mapped-annotations-roundtrip |
| C054 TypeHandler字段双向转换 | `TypeHandler`, `TypeHandlerFieldHandler` | [专题](../references/mapping.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C055 MappingStrategy写映射 | `MappingStrategy`, `MappingCache` | [专题](../references/mapping.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C056 ConversionStrategy读转换 | `ConversionStrategy`, `ConversionCache` | [专题](../references/mapping.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C057 MongoConverter整体替换 | `MongoConverter`, `MappingMongoConverter` | [专题](../references/mapping.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C058 自动填充 | `MetaObjectHandler`, `AutoFillMetaObject` | [专题](../references/mapping.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C059 FieldHandler写责任链 | `FieldHandler`, `FieldHandlerChain` | [专题](../references/extensions.md) | SOURCE_VERIFIED; LIVE_PARTIAL；field-chain-current-value |
| C060 ReadHandler读取链与中断 | `ReadHandler`, `HandlerCache` | [专题](../references/extensions.md) | SOURCE_VERIFIED; LIVE_PARTIAL；fieldbind-explicit-registration |
| C061 DBRef引用写读查询 | `DBRefHandler` | [专题](../references/mapping.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C062 ExtraFields额外字段 | `ExtraFieldsHolder`, `ExtraField` | [专题](../references/mapping.md) | SOURCE_VERIFIED; LIVE_PARTIAL；mapped-annotations-roundtrip |
| C063 FieldBind字典回写 | `DataBindHandler`, `FieldBindHandler` | [专题](../references/mapping.md) | SOURCE_VERIFIED; LIVE_PARTIAL; CONTRACT_UNRESOLVED；fieldbind-explicit-registration, fieldbind-camel-target |
| C064 字段加密与解密 | `Encryptor`, `EncryptorUtil`, `EncryptFieldHandler`, `FieldEncryptApply` | [专题](../references/field-security.md) | SOURCE_VERIFIED; LIVE_PARTIAL；mapped-annotations-roundtrip |
| C065 字段脱敏 | `DesensitizationHandler`, `DesensitizationHandlerApply` | [专题](../references/field-security.md) | SOURCE_VERIFIED; LIVE_PARTIAL；mapped-annotations-roundtrip |
| C066 敏感词局部全局及动态词库 | `SensitiveWordManager`, `SensitiveWordProperty`, `LoadExtraWord`, `SensitiveWordInterceptor` | [专题](../references/sensitive-word.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C067 普通拦截器与权限注入 | `Interceptor`, `InterceptorChain` | [专题](../references/interceptors.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C068 高级拦截器与执行改写 | `AdvancedInterceptor`, `Invocation`, `AdvancedInterceptorChain` | [专题](../references/interceptors.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C069 命令监听日志与错误通知 | `Listener`, `BaseListener`, `MongoPlusListener`, `LogListener` | [专题](../references/events.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C070 ConditionHandler条件转换 | `ConditionHandler`, `BuildCondition` | [专题](../references/extensions.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C071 Codec与JSR310类型 | `MongoPlusCodec`, `Jsr310CodecProvider` | [专题](../references/extensions.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C072 Aware命名空间事件 | `Aware`, `NamespaceAware` | [专题](../references/extensions.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C073 扩展对象注册与生命周期 | `Configuration`, `ComponentRegistry` | [专题](../references/extensions.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C074 多数据源声明与动态新增 | `DataSourceManager`, `MongoClientFactory` | [专题](../references/transactions-routing.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C075 动态物理集合 | `DynamicCollectionNameInterceptor`, `CollectionNameHandler` | [专题](../references/transactions-routing.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C076 编程式MongoDB事务 | `MongoTransactionalOperate`, `MongoTransactionalManager` | [专题](../references/transactions-routing.md) | SOURCE_VERIFIED; LIVE_PARTIAL；transaction-commit, transaction-rollback |
| C077 Spring事务与传播 | `MongoPlusTransactionalManager`, `MongoTransactionalAspect` | [专题](../references/transactions-routing.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C078 事务读偏好与选项 | `MongoTransactionalManager#startTransaction` | [专题](../references/transactions-routing.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C079 数据源分片与路由策略 | `DataSourceShardingStrategy`, `DataSourceShardingHandler` | [专题](../references/sharding.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C080 分片事务及Starter | `ShardingTransactionalHandler`, `MongoShardingConfiguration` | [专题](../references/sharding.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C081 多租户过滤 | `TenantHandler`, `TenantInterceptor`, `TenantManager` | [专题](../references/isolation.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C082 逻辑删除恢复与绕过 | `LogicRemove`, `LogicDeleteHandler`, `LogicManager` | [专题](../references/isolation.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C083 普通单字段唯一稀疏部分TTL索引 | `BaseIndex`, `IndexParser` | [专题](../references/indexes.md) | SOURCE_VERIFIED; LIVE_PARTIAL；ordinary-index-unique, annotation-parser-MongoIndex, annotation-parser-MongoIndexDs |
| C084 复合哈希地理传统文本索引 | `CompoundParser`, `HashParser`, `GeoParser`, `TextParser` | [专题](../references/indexes.md) | SOURCE_VERIFIED; PARSE_PASS_ONLY；annotation-parser-MongoCompoundIndex, annotation-parser-MongoCompoundIndexes, annotation-parser-MongoGeoIndex, annotation-parser-MongoHashIndex, annotation-parser-MongoTextIndex |
| C085 手工索引创建列举删除 | `BaseIndex`, `Index`, `SuperIndex` | [专题](../references/indexes.md) | SOURCE_VERIFIED; LIVE_PARTIAL；ordinary-index-unique |
| C086 Search静态动态多索引 | `SearchParse` | [专题](../references/search-vector.md) | SOURCE_VERIFIED; PARSE_PASS_ONLY；annotation-parser-MongoSearchIndex, annotation-parser-MongoSearchIndexes, annotation-parser-MongoSearchField, annotation-parser-MongoSearchFields |
| C087 Search分析器排序源字段同义词 | `SearchParse` | [专题](../references/search-vector.md) | SOURCE_VERIFIED; PARSE_PASS_ONLY；annotation-parser-MongoSearchSort, annotation-parser-MongoSearchSorts, annotation-parser-MongoSearchStoredSource, annotation-parser-MongoSearchSynonym |
| C088 VectorSearch向量过滤HNSW量化 | `VectorParse` | [专题](../references/search-vector.md) | SOURCE_VERIFIED; PARSE_PASS_ONLY；annotation-parser-MongoVectorIndex, annotation-parser-MongoVectorIndexes, annotation-parser-MongoVectorField, annotation-parser-MongoVectorFields, annotation-parser-MongoVectorHnswOptions, annotation-parser-MongoVectorStoredSource |
| C089 SearchVector状态冲突与幂等创建 | `AutoUtil#autoCreateIndexes`, `Resolver` | [专题](../references/search-vector.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C090 SearchVector查询与部署适配 | `Aggregate#custom` | [专题](../references/search-vector.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C091 自动时序集合 | `AutoUtil#autoCreateTimeSeries` | [专题](../references/timeseries.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C092 备份恢复与导出监听 | `BackupManager`, `BackupListener` | [专题](../references/backup-gridfs.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C093 GridFS上传与Driver下载 | `GridFSBucketManager` | [专题](../references/backup-gridfs.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C094 连接池TLS认证UUID与URI | `BaseProperty`, `UrlJoint`, `OverridableUuidRepresentationCodecProvider` | [专题](../references/configuration.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C095 配置模型优先级与绑定 | `MongoDBConnectProperty`, `MongoDBConfigurationProperty`, `MongoDBFieldProperty`, `MongoSpringProperty` | [专题](../references/configuration.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C096 配置加密环境后处理 | `EncryptionPostProcessor` | [专题](../references/configuration.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C097 异步镜像多写 | `AsyncMultipleWriteInterceptor`, `MultipleWriteHandler` | [专题](../references/events.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C098 数据变动记录 | `DataChangeRecorderInnerInterceptor` | [专题](../references/events.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C099 公开BSON工具与异常模型 | `MongoPlusDocument`, `MongoPlusBasicDBObject`, `MongoPlusException`, `OperationResult` | [专题](../references/utilities.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C100 源码索引开发工具 | `MongoPlusIndexerMain`, `ApiIndexer` | [专题](../references/tooling.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
| C101 外部持续变更流边界 | `com.mongodb.client.MongoCollection.watch（Driver边界）` | [专题](../references/driver-interop.md) | SOURCE_VERIFIED; UNVERIFIED / NOT_RUN；运行NOT_RUN |
