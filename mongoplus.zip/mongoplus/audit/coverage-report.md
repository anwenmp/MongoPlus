# MongoPlus Skill 覆盖审计 · 2026-11-11

仅重构当前`mongoplus/`。源码基线：POM 2.2.0、HEAD `1aacff901e33d33797cb957d883388519ef5ae6f`，逐文件SHA-256见[source-inventory](source-inventory.json)。未修改框架源码、其他目录或旧Skill；未安装、发布或打包ZIP。

## 盘点方法与计数口径

先用CodeGraph定位当前公开入口，再以JDK Compiler Tree API重新解析647个生产Java文件，生成覆盖矩阵后编写专题；旧API/能力索引只读作差异参考。当前共630个public类型声明，含嵌套类型与跨模块同名声明。注解为43种FQCN、44处声明，155个属性声明（Boot3/4同名声明分别计入）。测试语料跨6个模块，229个Java文件，见[只读测试交叉引用](test-corpus.json)；未执行原仓库全套测试，不将词法引用当作测试通过。

能力清单有**101行**：97项运行框架能力、1项BOM构件管理、1项源码索引工具（涵盖两个独立工程）、2项Driver互操作/缺口检查。此为按业务能力分组的审计口径，不等同于API方法数或全部重载运行通过。每行记录模块/API/注解/场景/注册/限制/专题；对应[完整清单](../capabilities.md)。

## 扫描模块

| 模块 | 根reactor | 生产Java文件 | public声明 | 测试Java文件 |
|---|---|---|---|---|
| mongo-plus-annotation | 是 | 85 | 84 | 0 |
| mongo-plus-bom | 否 | 0 | 0 | 0 |
| mongo-plus-boot-starter | 是 | 22 | 22 | 0 |
| mongo-plus-boot4-starter | 是 | 21 | 21 | 0 |
| mongo-plus-core | 是 | 470 | 468 | 0 |
| mongo-plus-indexer | 否 | 20 | 9 | 27 |
| mongo-plus-sensitive-word | 是 | 10 | 9 | 0 |
| mongo-plus-sharding | 是 | 7 | 7 | 0 |
| mongo-plus-sharding-boot-starter | 是 | 2 | 1 | 0 |
| mongo-plus-solon-plugin | 是 | 9 | 8 | 0 |
| mongo-plus-test | 否 | 0 | 0 | 168 |
| mongo-plus-test-boot3 | 否 | 0 | 0 | 13 |
| mongo-plus-test-boot4 | 否 | 0 | 0 | 18 |
| mongo-plus-test-solon | 否 | 0 | 0 | 2 |
| tools/mongoplus-api-indexer | 否 | 1 | 1 | 1 |

根POM实际聚合8个生产模块，BOM与indexer在仓库内但不在reactor；4个独立测试模块不作为发布功能模块。

## 注解覆盖

**43/43种、44/44处声明有记录，登记覆盖率100%；遗漏列表：空。** 每个记录含完整import、Target、默认值、实际用途、条件、限制、最小可编译声明和源码依据。容器、嵌套注解、类型提示均不排除。逐项[矩阵](annotation-matrix.md)与[注解入口](../annotations/index.md)。这项100%是文档登记与对账覆盖，不是运行通过率。

MongoSearchField.dimensions弃用；MongoReadPreference确认的消费点为MongoTransactional.preference第一项，独立方法注解使用未确认；NonNull/Nullable仅类型提示。FieldBind驼峰target场景保留未闭合记录。

## 功能与公开类型覆盖

**101/101行有专题与当前API来源，未登记能力列表：空。630/630个public声明有角色、源码和主题。** [功能矩阵](feature-matrix.md)、[全量公开类型与排除理由](public-types.md)。

角色统计：DEVELOPER_TOOL=8；INTEGRATION_SUPPORT=35；INTERNAL_PUBLIC=70；PUBLIC_ANNOTATION=42；PUBLIC_API=203；PUBLIC_SUPPORT=272。INTERNAL_PUBLIC仅排除逐个低层方法的业务教程化，不删除该类型记录；缓存、代理、执行器、日志、扫描、元信息等优先依赖公开上层接口。没有以“不常用”为理由排除公开功能。distinct/replaceOne/持续Change Streams没有框架专用入口的边界明确说明；不存在的LambdaQueryWrapper不编造。

## 本次验证

- 从当前源码直接javac：10/10个有生产源码的Maven工程通过；注解示例集合PASS。[构建结果](../validation/build-20261111T111900Z-4ed110/results.json)。Core/Annotation/可选模块/Solon采用release8，Starter与indexer按JDK17编译；未在独立JDK8/21 JVM运行。
- Markdown原文Java代码块：67/67编译通过，按块隔离包名，import、泛型、重载保留。[详细校验](../validation/checks-20261111T112045Z-e792d7/results.json)。
- 链接/锚点、注解源码差异、属性默认值、API来源、public角色、文件哈希：PASS。最终检查不把API出现次数当文档完成率。
- 收尾全量链接复查：PASS，1390条相对链接/锚点，[记录](../validation/final-links.json)。Java临时class和Python缓存已清理；源码、日志、命令和结果保留，重跑先执行compile_sources.py。[清理范围](../validation/cleanup.json)。
- 未改动的skill-creator quick_validate函数：PASS，输出`Skill is valid!`；本机缺PyYAML，使用现有SnakeYAML安全解析适配，未安装包。原生PyYAML路径为NOT_RUN。[适配与原结果](../validation/creator-validator/results.json)。
- 真实MongoDB 9.0.4 / JDK 17.0.20.1：39 LIVE_PASS、21 PARSE_PASS、2 NOT_RUN、1 CONTRACT_UNRESOLVED。[逐用例与原生命令对照](runtime-results.md)。创建集合46个，清理失败/残留0。
- 独立Agent行为首轮：2个评估者、16题均能找到功能族；首轮暴露的具体不足及后续修正保留在[评估A](../validation/forward-a/evaluation.md)、[评估B](../validation/forward-b/evaluation.md)，复评见各目录recheck.md。Agent导航不计真实库PASS。

- 另用不继承前文上下文的评估者做6题[盲测](../validation/blind/evaluation.md)，6/6现可完成API选择；注册签名/回调参数缺口与[复查](../validation/blind/fieldbind-recheck.md)保留。独立生成的7份Java答案由主代理以当前构件编译，7/7 COMPILE_PASS，运行NOT_RUN。[编译证据](../validation/blind-compile/results.json)。

## UNVERIFIED、争议及NOT_RUN

全部能力的未测重载/配置仍是UNVERIFIED；有LIVE_PARTIAL的行也只覆盖命名用例。以下事项没有被成功数掩盖：

- FieldBind.target=statusName：默认命名配置下真实读取抛出target field not found；label通过。契约CONTRACT_UNRESOLVED，未擅自标产品缺陷或修改源码。
- Search/Vector服务端管理不支持，代码31082；索引DDL、READY等待和实际搜索结果NOT_RUN。仅注解解析通过。
- Spring Boot3/4与Solon实际启动、代理事务传播/注解、SolonMongoDs/IgnoreTenant/IgnoreLogic接线组合NOT_RUN。Boot4/Solon的ReadHandler自动收集缺口按当前源码说明。
- 多数据源/动态集合/分片多资源事务、逻辑删除恢复、租户全执行面、bulk所有model、乐观锁全部重试、异步镜像故障一致性、数据变更审计、Codec/TLS真实握手、敏感词并发词库、时序DDL/TTL删除和备份恢复NOT_RUN。
- MongoTransactionalOperate的session与线程上下文/数据源参数边界、ResultHandler枚举无消费者、lazyDataSource与ignoreChar字段未确认生效；不把public声明当成可用配置保证。
- Codex/Claude Code/Kilo实际安装/自动发现、其他版本依赖、全部Java运行矩阵NOT_RUN；未安装任何Skill。

## 新旧差异

只读旧版`skills/mongoplus`实测10,584,468字节（约10MB），5份Markdown，5236条API索引记录。其索引包含30种注解FQCN，但这不能算注解开发文档。与当前43种比对，缺少14种当前FQCN，另外含1种当前不存在/迁移的旧FQCN。

| 对比项 | 旧10MB Skill | 被退回的当前版 | 本次重构 |
|---|---|---|---|
| 知识组织 | 入口+索引检索，3份references文档 | 10个常用主题 | 23个功能主题+验证页、10族精确签名、7组注解页+完整目录 |
| 注解 | 索引含30种，Markdown无独立完整记录 | 仅19个注解名以@形式出现，不能算完整记录 | 43种/44声明逐属性记录、示例编译与差异校验 |
| 能力证明 | API/capability索引数量 | 少量场景验收 | 101项逐行能力、全量声明角色、源码哈希和实际验证分层 |
| 新功能 | Search旧包，缺当前Search/Vector配置体系 | Search/Vector少量声明 | 多索引、字段/容器、分析器、sort、storedSource、synonyms、向量filter/HNSW/量化均可导航 |
| 可选与运维能力 | 可从索引找符号，缺开发专题 | 敏感词/分片/备份/配置等缺完整路由 | 独立专题、注册条件、限制和未验证项 |
| 体积目标 | 大量JSONL | 过度轻量导致遗漏 | 无硬性KB/MB目标；按需加载，不复制旧完整源码JSONL |

旧索引缺少的当前注解：

- `com.mongoplus.annotation.index.search.MongoSearchField`
- `com.mongoplus.annotation.index.search.MongoSearchFields`
- `com.mongoplus.annotation.index.search.MongoSearchIndex`
- `com.mongoplus.annotation.index.search.MongoSearchIndexes`
- `com.mongoplus.annotation.index.search.MongoSearchSort`
- `com.mongoplus.annotation.index.search.MongoSearchSorts`
- `com.mongoplus.annotation.index.search.MongoSearchStoredSource`
- `com.mongoplus.annotation.index.search.MongoSearchSynonym`
- `com.mongoplus.annotation.index.vector.MongoVectorField`
- `com.mongoplus.annotation.index.vector.MongoVectorFields`
- `com.mongoplus.annotation.index.vector.MongoVectorHnswOptions`
- `com.mongoplus.annotation.index.vector.MongoVectorIndex`
- `com.mongoplus.annotation.index.vector.MongoVectorIndexes`
- `com.mongoplus.annotation.index.vector.MongoVectorStoredSource`

旧索引额外项：`com.mongoplus.annotation.index.MongoSearchIndex`。旧记录里的SearchIndex包名不能照搬。对被退回当前版的原始字节数未保存可靠独立快照，不作体积比较；注解提及清单在[比较原始数据](predecessors.json)，仍不冒充覆盖率。

## 最终文档目录


annotations/：[field-processing.md](../annotations/field-processing.md)、[index.md](../annotations/index.md)、[indexes.md](../annotations/indexes.md)、[integration.md](../annotations/integration.md)、[mapping.md](../annotations/mapping.md)、[routing-isolation.md](../annotations/routing-isolation.md)、[search.md](../annotations/search.md)、[vector.md](../annotations/vector.md)。

references/：[aggregation.md](../references/aggregation.md)、[backup-gridfs.md](../references/backup-gridfs.md)、[configuration.md](../references/configuration.md)、[crud.md](../references/crud.md)、[driver-interop.md](../references/driver-interop.md)、[events.md](../references/events.md)、[expressions.md](../references/expressions.md)、[extensions.md](../references/extensions.md)、[field-security.md](../references/field-security.md)、[indexes.md](../references/indexes.md)、[integration.md](../references/integration.md)、[interceptors.md](../references/interceptors.md)、[isolation.md](../references/isolation.md)、[mapping.md](../references/mapping.md)、[query.md](../references/query.md)、[search-vector.md](../references/search-vector.md)、[sensitive-word.md](../references/sensitive-word.md)、[sharding.md](../references/sharding.md)、[timeseries.md](../references/timeseries.md)、[tooling.md](../references/tooling.md)、[transactions-routing.md](../references/transactions-routing.md)、[update.md](../references/update.md)、[utilities.md](../references/utilities.md)、[verification.md](../references/verification.md)。

references/api/：[aggregation.md](../references/api/aggregation.md)、[data-access.md](../references/api/data-access.md)、[expressions.md](../references/api/expressions.md)、[extensions.md](../references/api/extensions.md)、[index.md](../references/api/index.md)、[management.md](../references/api/management.md)、[mapping.md](../references/api/mapping.md)、[optional-modules.md](../references/api/optional-modules.md)、[query.md](../references/api/query.md)、[update.md](../references/api/update.md)、[utilities.md](../references/api/utilities.md)。

## 官方参考与源码差异

已查阅[开放Agent Skills规范](https://agentskills.io/specification)、[MongoPlus官网](https://mongoplus.com/)、[注解](https://mongoplus.com/docs/annotation.html)、[聚合](https://mongoplus.com/docs/aggregate.html)、[配置](https://mongoplus.com/docs/property.html)、[自动索引](https://mongoplus.com/docs/autoCreateIndex.html)、[敏感词](https://mongoplus.com/docs/sensitiveWord.html)、[备份](https://mongoplus.com/docs/dataBackup.html)。官网首页BOM示例仍为2.1.9；本地POM为2.2.0。官方注解页的CollectionField.convertCollect不在当前声明；TimeSeries源注释含没有value成员的旧简写，已在新记录纠正。源码与官网差异保留，不从文档单方认定产品缺陷。
