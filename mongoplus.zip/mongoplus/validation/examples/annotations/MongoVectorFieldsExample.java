import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.index.vector.MongoVectorField;
import com.mongoplus.annotation.index.vector.MongoVectorFields;
import com.mongoplus.annotation.index.vector.MongoVectorIndex;
import com.mongoplus.annotation.index.vector.MongoVectorIndexes;
import com.mongoplus.enums.SearchVectorSimilarity;

@CollectionName("example_mongovectorfields") @MongoVectorIndexes({@MongoVectorIndex(name="a"),@MongoVectorIndex(name="b")}) public class MongoVectorFieldsExample { @MongoVectorFields({@MongoVectorField(name="a",numDimensions=3,similarity=SearchVectorSimilarity.COSINE),@MongoVectorField(name="b",numDimensions=3,similarity=SearchVectorSimilarity.COSINE)}) java.util.List<Double> embedding; }
