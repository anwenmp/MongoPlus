import com.mongoplus.annotation.mapper.Mongo;

@Mongo public interface MongoExample extends com.mongoplus.mapper.MongoMapper<MongoExample.Entity> { class Entity {} }
