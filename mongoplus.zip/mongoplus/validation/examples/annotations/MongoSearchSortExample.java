import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.index.search.MongoSearchField;
import com.mongoplus.annotation.index.search.MongoSearchIndex;
import com.mongoplus.annotation.index.search.MongoSearchSort;
import com.mongoplus.enums.SearchFieldType;

@CollectionName("example_mongosearchsort") @MongoSearchIndex(name="articles",fields={@MongoSearchField(fieldName="title",type=SearchFieldType.TOKEN)},sort={@MongoSearchSort(fieldName="title")}) public class MongoSearchSortExample {}
