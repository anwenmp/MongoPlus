import com.mongoplus.annotation.ID;

public class IDExample { @ID String id; }
