import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.index.search.MongoSearchIndex;
import com.mongoplus.annotation.index.search.MongoSearchStoredSource;

@CollectionName("example_mongosearchstoredsource") @MongoSearchIndex(dynamic=true,storedSource=@MongoSearchStoredSource(include={"title"})) public class MongoSearchStoredSourceExample {}
