import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.index.MongoCompoundIndex;

@CollectionName("example_mongocompoundindex") @MongoCompoundIndex(value="{\"tenant\":1,\"created_at\":-1}", name="tenant_time") public class MongoCompoundIndexExample {}
