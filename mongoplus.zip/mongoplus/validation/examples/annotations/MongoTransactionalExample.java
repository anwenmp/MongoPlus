import com.mongoplus.annotation.transactional.MongoTransactional;

public class MongoTransactionalExample { @MongoTransactional(rollbackFor=Exception.class) public void saveBoth(){} }
