import com.mongoplus.annotation.datasource.MongoDs;

@MongoDs("archive") public class MongoDsExample { void query(){} }
