import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.index.search.MongoSearchField;
import com.mongoplus.annotation.index.search.MongoSearchIndex;

@CollectionName("example_mongosearchfield") @MongoSearchIndex(name="articles") public class MongoSearchFieldExample { @MongoSearchField String title; }
