import com.mongoplus.annotation.MongoMapperScan;

@MongoMapperScan("example.mapper") public class MongoMapperScanExample {}
