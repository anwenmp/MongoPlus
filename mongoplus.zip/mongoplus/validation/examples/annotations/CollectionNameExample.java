import com.mongoplus.annotation.collection.CollectionName;

@CollectionName("orders") public class CollectionNameExample { String title; }
