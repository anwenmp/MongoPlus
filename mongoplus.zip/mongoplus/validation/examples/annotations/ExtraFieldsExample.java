import com.mongoplus.annotation.collection.ExtraFields;

public class ExtraFieldsExample { @ExtraFields java.util.Map<String,Object> extra; }
