import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.index.search.MongoSearchField;
import com.mongoplus.annotation.index.search.MongoSearchFields;
import com.mongoplus.annotation.index.search.MongoSearchIndex;
import com.mongoplus.enums.SearchFieldType;

@CollectionName("example_mongosearchfields") @MongoSearchIndex(name="articles") public class MongoSearchFieldsExample { @MongoSearchFields({@MongoSearchField(type=SearchFieldType.STRING),@MongoSearchField(type=SearchFieldType.TOKEN)}) String title; }
