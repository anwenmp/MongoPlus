import com.mongoplus.annotation.ID;
import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.collection.DBRef;

public class DBRefExample { @DBRef Target customer; @CollectionName("customers") public static class Target { @ID public String id; } }
