import com.mongoplus.annotation.transactional.MongoReadPreference;
import com.mongoplus.annotation.transactional.MongoTransactional;
import com.mongoplus.enums.ReadPreferenceEnum;

public class MongoReadPreferenceExample { @MongoTransactional(preference={@MongoReadPreference(preferenceEnum=ReadPreferenceEnum.PRIMARY)}) public void save(){} }
