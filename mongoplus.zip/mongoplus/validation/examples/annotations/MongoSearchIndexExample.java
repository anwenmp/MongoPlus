import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.index.search.MongoSearchField;
import com.mongoplus.annotation.index.search.MongoSearchIndex;

@CollectionName("example_mongosearchindex") @MongoSearchIndex(name="articles", fields={@MongoSearchField(fieldName="title")}) public class MongoSearchIndexExample {}
