import com.mongoplus.annotation.SensitiveWord;

public class SensitiveWordExample { @SensitiveWord String body; }
