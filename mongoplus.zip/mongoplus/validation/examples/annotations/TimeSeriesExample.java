import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.collection.TimeSeries;

@CollectionName("measurements") @TimeSeries(timeField="time", metaField="sensor") public class TimeSeriesExample { java.util.Date time; String sensor; }
