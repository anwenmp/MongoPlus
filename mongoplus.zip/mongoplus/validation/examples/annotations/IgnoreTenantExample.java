import com.mongoplus.annotation.tenant.IgnoreTenant;

public class IgnoreTenantExample { @IgnoreTenant public void maintenance(){} }
