import com.mongoplus.annotation.comm.NonNull;

public class NonNullExample { @NonNull String value; }
