import com.mongoplus.annotation.collection.CollectionField;
import com.mongoplus.annotation.collection.FieldBind;

public class FieldBindExample { @FieldBind(type="status", target="label") String status; @CollectionField(exist=false) String label; }
