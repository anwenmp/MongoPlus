# 独立业务导航复验 A

仅阅读更新后的SKILL.md及其链接资料；未读取仓库源码、旧索引，未连接数据库。只写本文件。下面代码按Skill已列出的import/重载组织，本复验没有另行调用编译器：本复验编译NOT_RUN、数据库运行NOT_RUN。文档已有实测记录不冒充本评估执行。

## 1. 在绑定Mapper上删除items中sku=X且qty>=2的元素

导航：SKILL.md → references/update.md → references/api/update.md及api/data-access.md。更新专题现已给出两个明确公开重载：`pull(String,Object)`与`pull(Wrapper<?>)`，以及真实命令及原生对照结果链接。可以闭合构造与执行入口：

```java
import com.mongoplus.conditions.query.QueryWrapper;
import com.mongoplus.conditions.update.UpdateWrapper;
import com.mongoplus.mapper.MongoMapper;
import org.bson.Document;

class PullItemsForBoundMapper {
    static <T> UpdateWrapper<T> byField(Object id) {
        Document element = new Document("sku", "X")
            .append("qty", new Document("$gte", 2));
        return new UpdateWrapper<T>().eq("_id", id).pull("items", element);
    }

    static <T> UpdateWrapper<T> byWrapper(Object id) {
        Document element = new Document("sku", "X")
            .append("qty", new Document("$gte", 2));
        QueryWrapper<Object> pullBody = new QueryWrapper<Object>()
            .custom(new Document("items", element));
        return new UpdateWrapper<T>().eq("_id", id).pull(pullBody);
    }

    static <T> Boolean removeUsingFieldOverload(MongoMapper<T> mapper, Object id) {
        return mapper.getBaseMapper().updateOne(
            PullItemsForBoundMapper.<T>byField(id), mapper.getGenericityClass(), null);
    }

    static <T> Boolean removeUsingWrapperOverload(MongoMapper<T> mapper, Object id) {
        return mapper.getBaseMapper().updateOne(
            PullItemsForBoundMapper.<T>byWrapper(id), mapper.getGenericityClass(), null);
    }
}
```

这两个方法是备选调用，不对同一测试数据连续执行后拿第二次布尔值判失败。目标更新体均为`{$pull:{items:{sku:"X",qty:{$gte:2}}}}`。`eq("items",element)`会额外套$eq而改变语义；pullAll也不是条件删除。id必须与实际持久化BSON类型相符。构造通过MongoPlus更新链/Mapper执行，未改用Driver。

复验：CLOSED。初次评估的“数组路径与内部条件不明确”已消除；范围限于这两个具体重载，其他重载仍需分别验证。

## 2. 两个自定义字段转换依次运行且早于加密

导航：SKILL.md → references/extensions.md → references/field-security.md。现在文档给出精确默认order：TypeHandler为0、EncryptFieldHandler为Integer.MAX_VALUE-1、DBRef为Integer.MAX_VALUE；敏感词LOCAL节点为Integer.MIN_VALUE。故自定义10和20分别在类型处理之后、加密之前。

```java
import com.mongoplus.annotation.comm.FieldEncrypt;
import com.mongoplus.handlers.FieldHandler;
import com.mongoplus.handlers.FieldHandlerChain;
import com.mongoplus.mapping.FieldInformation;
import java.util.Locale;
import java.util.function.Function;

class BeforeEncryption {
    abstract static class SecretTransform implements FieldHandler {
        public Function<FieldInformation, Boolean> activate() {
            return f -> "secret".equals(f.getName()) && f.isAnnotation(FieldEncrypt.class);
        }
        public Object handler(FieldInformation f) {
            return handler(f, f.getValue());
        }
        public abstract Object handler(FieldInformation f, Object currentValue);
    }

    static class Trim extends SecretTransform {
        public Integer order() { return 10; }
        public Object handler(FieldInformation f, Object currentValue) {
            return currentValue instanceof String ? ((String) currentValue).trim() : currentValue;
        }
    }

    static class Upper extends SecretTransform {
        public Integer order() { return 20; }
        public Object handler(FieldInformation f, Object currentValue) {
            return currentValue instanceof String
                ? ((String) currentValue).toUpperCase(Locale.ROOT) : currentValue;
        }
    }

    static void registerOnceAtStartup() {
        FieldHandlerChain.getInstance().register(new Trim());
        FieldHandlerChain.getInstance().register(new Upper());
    }
}
```

实体secret字段还需@FieldEncrypt以及所选算法的合法密钥/Encryptor配置。链注册即排序；MappingMongoConverter将前序的最新currentValue传给后一节点，null返回表示不替换。不能让Upper从`f.getValue()`重新取原值，否则会丢失Trim结果。保留单参数方法只是满足兼容接口，主处理写双参数。只在启动注册一次，不将静态链当请求级对象，也不假设普通Handler Bean自动被收集。

复验：CLOSED。精确order与当前值语义足以从资料决定顺序；所有实体/Document/raw BSON入口的覆盖仍不能外推。

## 3. title全文检索并预排序title的合法静态配置

导航：SKILL.md → references/search-vector.md → annotations/search.md。预排序字段需要支持排序的静态类型；title全文字符串映射与TOKEN排序映射可作为同一字段的多类型定义：

```java
import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.index.search.MongoSearchField;
import com.mongoplus.annotation.index.search.MongoSearchIndex;
import com.mongoplus.annotation.index.search.MongoSearchSort;
import com.mongoplus.enums.SearchFieldType;

@CollectionName("articles")
@MongoSearchIndex(name="articles_title", fields={
    @MongoSearchField(fieldName="title", type=SearchFieldType.STRING),
    @MongoSearchField(fieldName="title", type=SearchFieldType.TOKEN)
}, sort={@MongoSearchSort(fieldName="title")})
class SearchAndSortTitle {
    String title;
}
```

如果只需要预排序而没有全文需求，TOKEN静态定义足够；这里保留STRING用于全文查询。嵌套fields/sort内name留空，索引归属由外层确定。启用auto-create-index并扫描实体或显式AutoUtil自动创建；部署须支持Search及此选项，创建异步，查询需匹配$search.sort且检查索引可查询状态。仅dynamic=true不会满足静态排序映射。

复验：CLOSED。MongoSearchSort及Sorts的独立示例现已补TOKEN静态映射，初次的示例/契约冲突已修复。

## 4. 窗口阶段的精确参数类名与import

导航：SKILL.md → references/aggregation.md → references/api/aggregation.md。正文已改为WindowOutputField；API页现保留原声明import，窗口参数由`com.mongodb.client.model.*`导入，补点和填充的子包明确列出。因此可确认以下import及签名，而无需编造WindowedComputation：

```java
import com.mongoplus.aggregate.AggregateWrapper;
import com.mongodb.client.model.WindowOutputField;
import com.mongodb.client.model.densify.DensifyRange;
import com.mongodb.client.model.densify.DensifyOptions;
import com.mongodb.client.model.fill.FillOptions;
import com.mongodb.client.model.fill.FillOutputField;
import org.bson.conversions.Bson;

class TypedWindowInputs {
    static AggregateWrapper window(Object partitionBy, Bson sortBy, WindowOutputField output) {
        return new AggregateWrapper().setWindowFields(partitionBy, sortBy, output);
    }
    static AggregateWrapper densify(DensifyRange range, DensifyOptions options) {
        return new AggregateWrapper().densify("time", range, options);
    }
    static AggregateWrapper fill(FillOptions options, FillOutputField output) {
        return new AggregateWrapper().fill(options, output);
    }
}
```

Skill还列出Iterable及Bson重载：`setWindowFields(Bson)`接完整阶段，不能传内部参数体。上例只展示可以确认的类型化方法连接，不编造Driver工厂方法或默认窗口边界。实际创建WindowOutputField、范围和填充输出对象时，仍应核对项目解析到的Driver版本或官方API；设备分区、排序、缺点范围与窗口结果必须实际运行。原声明的通配符import能确定WindowOutputField所在包，当前资料不再缺参数包信息。

复验：CLOSED（参数类名/import与MongoPlus重载）；完整设备统计的值构造和运行契约不在本复验中确认。

## 结果

4项需求均已能从当前Skill资料闭合到真实公开入口、import及关键边界。没有新增猜测的框架方法或Driver类型。新增代码的本复验编译、真实MongoDB执行及跨客户端验证均NOT_RUN；以上结论是独立导航/选型复验，不是新的运行通过数。
