# 独立业务导航评估 A

评估输入：仅从本Skill的SKILL.md按需导航；未读取仓库源码、旧索引，未连接数据库、安装或发布。下述API来源于Skill本身，代码为选型示例，未由本评估编译或执行。运行状态统一NOT_RUN，不能据此增加LIVE_PASS。

## 1. 两个Search索引各自配置同义词、storedSource及预排序

路径：SKILL.md → references/search-vector.md → annotations/index.md → annotations/search.md。

找到完整公开注解：

```java
import com.mongoplus.annotation.index.search.MongoSearchIndex;
import com.mongoplus.annotation.index.search.MongoSearchField;
import com.mongoplus.annotation.index.search.MongoSearchSort;
import com.mongoplus.annotation.index.search.MongoSearchStoredSource;
import com.mongoplus.annotation.index.search.MongoSearchSynonym;
import com.mongoplus.enums.SearchFieldType;
import com.mongoplus.enums.IndexDirection;

@MongoSearchIndex(name="catalog_a", fields={
    @MongoSearchField(fieldName="title"),
    @MongoSearchField(fieldName="publishedAt",type=SearchFieldType.DATE)
}, sort={@MongoSearchSort(fieldName="publishedAt",order=IndexDirection.DESC)},
    storedSource=@MongoSearchStoredSource(include={"title","publishedAt"}),
    synonyms={@MongoSearchSynonym(name="terms_a",sourceCollection="synonyms_a")})
@MongoSearchIndex(name="catalog_b", fields={
    @MongoSearchField(fieldName="title"),
    @MongoSearchField(fieldName="publishedAt",type=SearchFieldType.DATE)
}, sort={@MongoSearchSort(fieldName="publishedAt")},
    storedSource=@MongoSearchStoredSource(include={"title"}),
    synonyms={@MongoSearchSynonym(name="terms_b",sourceCollection="synonyms_b")})
class TwoSearchIndexes {}
```

注册：启用auto-create-index并扫描实体，或使用AutoUtil.autoCreateIndexes；支持Search的部署及已有同库同义词集合。每个索引的嵌套fields/sort内name留空，由外层索引归属。预排序字段须静态映射为允许类型，DATE例避免将STRING直接作为排序映射。查询也要指定匹配的$search.sort并引用同义词名；声明不会写入来源词库，也不保证READY。storedSource include/exclude/value互斥。

导航结果：PASS。发现文档自相矛盾：MongoSearchSortExample只有dynamic=true及title排序，无静态字段映射；同页sort契约明确动态映射不满足预排序条件。MongoSearchSortsExample也仅dynamic=true。建议修复示例后用真实解析器验证，而不只编译。

## 2. 同一embedding对应两个Vector索引并添加tenant过滤字段

路径：references/search-vector.md → annotations/vector.md；枚举完整类名可在references/api/utilities.md查到。

```java
import com.mongoplus.annotation.index.vector.MongoVectorIndex;
import com.mongoplus.annotation.index.vector.MongoVectorField;
import com.mongoplus.enums.VectorFieldType;
import com.mongoplus.enums.SearchVectorSimilarity;
import java.util.List;

@MongoVectorIndex(name="vec_a",fields={
    @MongoVectorField(fieldName="tenant_id",type=VectorFieldType.FILTER)
})
@MongoVectorIndex(name="vec_b",fields={
    @MongoVectorField(fieldName="tenant_id",type=VectorFieldType.FILTER)
})
class TwoVectorIndexes {
    @MongoVectorField(name="vec_a",numDimensions=3,similarity=SearchVectorSimilarity.COSINE)
    @MongoVectorField(name="vec_b",numDimensions=3,similarity=SearchVectorSimilarity.COSINE)
    List<Double> embedding;
}
```

类级filter与字段向量配置合并，每个索引得到一个vector和一个filter。类有多个索引时字段注解必须指定name；FILTER不能填向量维度、相似度等选项。维度与实际embedding匹配，Search和Vector索引同名冲突；支持部署、自动扫描/创建、异步就绪均需独立确认。tenant filter字段声明不会自动给查询填租户条件，应在查询阶段构建受信filter。

导航结果：PASS；参数/注册/限制足够定位。没有把它误选为MongoSearchField的旧knnVector路径。

## 3. Boot4读取状态码后回写状态名称

路径：references/mapping.md → annotations/mapping.md#fieldbind → references/extensions.md → references/integration.md；精确接口见references/api/mapping.md。

选择`com.mongoplus.annotation.collection.FieldBind`，在status上指定`type="status",target="statusName"`；目标非持久化字段可用`CollectionField(exist=false)`。业务实现`com.mongoplus.handlers.DataBindHandler`的`void setMetaObject(FieldBind,Object,FieldInformation)`，对传入目标FieldInformation调用`setValue(Object)`。启动时通过`com.mongoplus.cache.global.HandlerCache.addReadHandler(new com.mongoplus.handlers.read.FieldBindHandler(handler))`显式注册一次。

Skill明确Boot4没有Boot3末尾收集自定义ReadHandler Bean的步骤，因此不能只暴露一个ReadHandler Bean便声称生效。回调是读取源字段后填同一对象目标，不是保存时做外表联查；目标字段必须存在。type为业务字典标识。

导航结果：PASS。注解示例与注册提示可用；回调示例缺少一份完整可编译的Boot4初始化用法，当前需要结合签名组装。跨容器运行NOT_RUN。

## 4. 两个自定义字段处理器串联再加密

路径：references/extensions.md → references/field-security.md → annotations/field-processing.md → references/api/extensions.md。

选择`com.mongoplus.handlers.FieldHandler`的双参数`handler(com.mongoplus.mapping.FieldInformation,Object currentValue)`，每个节点处理前序currentValue；返回null意为不替换当前值。显式在`FieldHandlerChain.getInstance().register/registerAll`注册，不假定普通Bean被扫描。两个自定义节点给不同order，且order均在内置`com.mongoplus.handlers.field.EncryptFieldHandler`之前；只activate目标字段；实体加`com.mongoplus.annotation.comm.FieldEncrypt`并配置合法密钥/自定义Encryptor。保留旧单参数实现以满足接口，但主要逻辑写双参数，避免第二节点又读取原始字段。

导航结果：PARTIAL。链的最新值传递、注册时排序、null语义和旧兼容方法均解释清楚，能避免历史误判；但Skill只列EncryptFieldHandler.order()签名，没有标其实际order值。若要仅凭文档明确选10/20保证先于加密仍需读取返回值/源码，不能推测。可以在代码初始化时询问内置handler.order()后安排值，但不宜用此规避缺失的稳定说明。建议文档给当前默认节点精确order与限制。

## 5. 部门权限覆盖查询、修改、分页计数并保留原条件

路径：references/interceptors.md；签名来自references/api/extensions.md。

使用`com.mongoplus.interceptor.Interceptor`，注册为Starter Bean或Configuration.interceptor对应入口。受信身份取得部门集合，原filter与`com.mongoplus.toolkit.Filters.in("department_id",allowed)`通过Filters.and组合。查找用`QueryParam executeQuery(Bson,BasicDBObject,BasicDBObject,MongoCollection<Document>)`保留投影/排序。修改用`MutablePair<Bson,Bson> executeUpdate(MutablePair<Bson,Bson>,MongoCollection<Document>)`只改left的filter，right也要限制可写字段、拒绝修改归属与不允许的upsert。

分页总数需同样处理`MutablePair<BasicDBObject,CountOptions> executeCount(BasicDBObject,CountOptions,MongoCollection<Document>)`，保留CountOptions。`executeEstimatedDocumentCount`无法带权限filter，应拒绝或让服务显式提供可信条件以走准确计数；空部门$in:[]。beforeExecute需允许已实现QUERY/COUNT/允许的更新路径，索引枚举可能null，其他未覆盖写入保持拒绝。

导航结果：PASS，且文档没有将局部部门示例误称完整权限实现。注意现有DepartmentReads示例的beforeExecute仅允许QUERY与UPDATE_ONE，COUNT会被拒绝；文档表已说明分页计数“应实现”的额外边界，使用者必须补齐，不能原样复制后承诺分页可用。运行验证应包含越权、空权限、用户伪造条件、分页总数、同值更新和bulk等。

## 6. 每设备按时间做窗口统计并补缺失采样点

路径：references/aggregation.md → references/api/aggregation.md。

找到MongoPlus的`AggregateWrapper`，高层入口为setWindowFields、densify、fill。精确签名页给出：

- `setWindowFields(TExpression partitionBy,Bson sortBy,WindowOutputField output,WindowOutputField... moreOutput)`及Iterable/Bson重载。
- `densify(String field,DensifyRange range,DensifyOptions options)`及SFunction/Bson重载。
- `fill(FillOptions options,FillOutputField output,FillOutputField... moreOutput)`及Iterable/Bson重载。

这些Bson重载接收完整阶段。可用`import com.mongoplus.aggregate.AggregateWrapper; import org.bson.Document;`及`.densify(new Document("$densify",body)).fill(new Document("$fill",body)).setWindowFields(new Document("$setWindowFields",body))`保留MongoPlus执行与结果映射，避免绕到Driver直接aggregate。但各body的partition、时间步长、窗口边界和排序需要根据目标版本做真实命令与结果实验，不能在未运行时推断。

导航结果：PARTIAL。主专题写“WindowedComputation等Driver值类型”，签名却是WindowOutputField，存在明显命名冲突。签名页也未列WindowOutputField/DensifyRange/DensifyOptions/FillOptions/FillOutputField的完整import，不足以从Skill单独编写类型化重载；可退到完整Bson阶段，但这不应代替修正高层类型说明。建议提供一份设备分区、时间顺序、补点与窗口的实际执行示例。

## 7. 数组删除同时满足多个条件的元素

路径：references/update.md → references/api/update.md。

候选公开API：`com.mongoplus.conditions.update.UpdateWrapper<T>`继承的`pull(String,Object)`、`pull(Wrapper<?>)`及`pull(SFunction<QueryWrapper<T>,QueryWrapper<T>>)`；条件构造器为`com.mongoplus.conditions.query.QueryWrapper`。执行用绑定更新链或BaseMapper.updateOne/update选择单条/多条范围。不能选pullAll，因为它是多个精确值而非条件谓词。

导航结果：PARTIAL / CONTRACT_UNRESOLVED。Skill准确提醒pull的值和wrapper重载不能互推，但没有说明`pull(Wrapper<?>)`如何表达“目标数组字段→元素条件”这两层，亦无完整实发update例。只知道方法存在，不足以确认合法条件构造。`updateCustom(Bson)`提供显式完整`$pull:{items:{status:...,qty:...}}`更新体候选入口，依旧需确认该入口实际生成命令并执行。评估不会凭方法名编造合法wrapper示例。建议补最小数组数据、多条件反例、精确重载和真实/native对照结果。

## 8. 已有MongoMapper获取category去重值

路径：SKILL.md直接有distinct/replaceOne路由 → references/driver-interop.md → references/aggregation.md / references/api/data-access.md。

若category已确认标量且业务接受分组结果，优先`com.mongoplus.aggregate.AggregateWrapper.group("$category")`，通过`com.mongoplus.mapper.MongoMapper<T>.list(Aggregate<?>,Class<R>)`以`org.bson.Document.class`接收再读取_id。需明确null、缺字段、数组值与顺序要求，不能将group无条件宣称完全等同distinct。

确需Driver distinct语义/选项，Skill明确当前MongoPlus无专用方法；通过`mapper.getCollection().distinct("category",String.class).into(new java.util.ArrayList<String>())`。Driver调用不会自动经过租户/逻辑删除/版本/转换执行链，必须显式受信filter、最终namespace及同client session，不能在有权限隔离时无条件照搬无filter示例。

导航结果：PASS。没有编造BaseMapper.distinct，也没有引入MyBatis-Plus接口。

## 评估结论与待修清单

8题均能找到正确功能族；5题达到可据文档选用入口、注册和关键边界，3题仍需更具体契约或类型说明。这里的PASS只是导航和选型审阅，全部代码编译与真实运行均NOT_RUN。

1. SearchSort及Sorts最小示例与静态排序映射契约冲突，应补合法静态字段映射，并运行解析器。
2. 聚合窗口说明WindowedComputation与签名WindowOutputField冲突；API参数类型缺完整import映射。
3. 字段链节点缺当前精确order值；同字段串联后加密的顺序不能只凭示例order10外推。
4. Pull wrapper缺目标数组与内部谓词的具体合法构造和完整真实update，不能将方法登记当成已掌握用法。
5. Search属性Javadoc的JSON片段出现代码标记提前闭合，复制示例会受影响；正文Java代码块未见同类现象。
6. 评估期间coverage-report.md尚未出现，入口链接待主任务最后生成后检查。

本评估未改变Skill文档，没有声明任何源码确认或数据库测试通过。
