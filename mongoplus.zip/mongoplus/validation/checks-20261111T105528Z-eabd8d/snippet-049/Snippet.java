package skillcheck.c49;
import com.mongodb.client.ChangeStreamIterable;
import com.mongodb.client.MongoChangeStreamCursor;
import com.mongodb.client.model.changestream.ChangeStreamDocument;
import com.mongodb.client.model.changestream.FullDocument;
import com.mongoplus.mapper.MongoMapper;
import org.bson.BsonDocument;
import org.bson.Document;

class OrderChanges {
    static MongoChangeStreamCursor<ChangeStreamDocument<Document>> open(
            MongoMapper<?> orders, BsonDocument checkpoint) {
        ChangeStreamIterable<Document> stream = orders.getCollection().watch()
            .fullDocument(FullDocument.UPDATE_LOOKUP);
        if (checkpoint != null) stream = stream.resumeAfter(checkpoint);
        return stream.cursor();
    }
}
