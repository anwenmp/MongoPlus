package skillcheck.c22;
import com.mongoplus.annotation.ID;

class IDExample { @ID String id; }
