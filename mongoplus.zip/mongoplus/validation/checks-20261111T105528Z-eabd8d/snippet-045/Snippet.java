package skillcheck.c45;
import com.mongoplus.grid.GridFSBucketManager;
import org.bson.types.ObjectId;

class StoreAttachment {
    static ObjectId upload(String database, byte[] bytes) {
        return GridFSBucketManager.create(database,"attachments").upload(bytes,"note.txt");
    }
}
