package skillcheck.c19;
import com.mongoplus.annotation.comm.EnumValue;

enum EnumValueExample { OPEN(1); @EnumValue final int code; EnumValueExample(int code){this.code=code;} }
