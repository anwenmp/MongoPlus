package skillcheck.c12;
import com.mongoplus.annotation.index.MongoTextIndex;

@MongoTextIndex(fields={"title","body"}, name="article_text") class MongoTextIndexExample {}
