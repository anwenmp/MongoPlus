package skillcheck.c8;
import com.mongoplus.annotation.index.MongoGeoIndex;
import com.mongoplus.enums.GeoType;

class MongoGeoIndexExample { @MongoGeoIndex(type=GeoType.SPHERE) Object location; }
