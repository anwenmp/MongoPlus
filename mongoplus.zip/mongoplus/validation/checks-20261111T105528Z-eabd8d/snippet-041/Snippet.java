package skillcheck.c41;
import com.mongoplus.annotation.index.vector.MongoVectorField;
import com.mongoplus.annotation.index.vector.MongoVectorIndex;
import com.mongoplus.enums.SearchVectorSimilarity;

@MongoVectorIndex(name="vec",fields={@MongoVectorField(fieldName="embedding",numDimensions=3,similarity=SearchVectorSimilarity.COSINE)}) class MongoVectorIndexExample {}
