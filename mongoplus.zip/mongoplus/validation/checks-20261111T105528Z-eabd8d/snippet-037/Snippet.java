package skillcheck.c37;
import com.mongoplus.annotation.index.search.MongoSearchIndex;
import com.mongoplus.annotation.index.search.MongoSearchSynonym;

@MongoSearchIndex(dynamic=true,synonyms={@MongoSearchSynonym(name="terms",sourceCollection="synonyms")}) class MongoSearchSynonymExample {}
