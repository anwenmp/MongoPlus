package skillcheck.c64;
import com.mongoplus.annotation.ID;
import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.collection.Version;
import com.mongoplus.conditions.query.QueryWrapper;
import com.mongoplus.mapper.BaseMapper;

@CollectionName("drafts")
public class Draft {
    @ID public String id;
    @Version public Integer version;
    public String title;

    boolean saveEdit(BaseMapper mapper) {
        if (id == null || version == null) throw new IllegalArgumentException("ID and version required");
        return mapper.updateOne(this, new QueryWrapper<Draft>().eq("_id", id), null);
    }
}
