package skillcheck.c58;
import com.mongoplus.conditions.query.QueryWrapper;
import com.mongoplus.enums.RegexOptions;
import com.mongoplus.mapper.MongoMapper;
import java.util.List;
import java.util.regex.Pattern;
import org.bson.Document;

class OrderFilters {
    static <T> QueryWrapper<T> shortlist(int low, int high, String prefix) {
        return new QueryWrapper<T>()
            .gte("amount", low).lt("amount", high)
            .or(q -> q.regex("title", "^" + Pattern.quote(prefix), RegexOptions.UNICODE)
                      .eq("urgent", true))
            .orderByDesc("amount").orderByAsc("_id")
            .projectDisplay("_id", "amount");
    }

    static <T> List<Document> rows(MongoMapper<T> orders, String prefix) {
        return orders.list(shortlist(10, 20, prefix), Document.class);
    }

    static <T> QueryWrapper<T> byLot(String site, String sku, int minimum) {
        QueryWrapper<Object> lot = new QueryWrapper<Object>()
            .eq("sku", sku).gte("qty", minimum);
        QueryWrapper<Object> shipment = new QueryWrapper<Object>()
            .eq("site", site).elemMatch("lots", lot);
        return new QueryWrapper<T>().elemMatch("shipments", shipment);
    }
}
