package skillcheck.c34;
import com.mongoplus.annotation.index.search.MongoSearchIndex;
import com.mongoplus.annotation.index.search.MongoSearchSort;

@MongoSearchIndex(name="articles",dynamic=true,sort={@MongoSearchSort(fieldName="title")}) class MongoSearchSortExample {}
