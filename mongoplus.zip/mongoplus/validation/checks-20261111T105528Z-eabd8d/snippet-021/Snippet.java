package skillcheck.c21;
import com.mongoplus.annotation.collection.CollectionField;
import com.mongoplus.annotation.collection.FieldBind;

class FieldBindExample { @FieldBind(type="status", target="statusName") String status; @CollectionField(exist=false) String statusName; }
