package skillcheck.c52;
import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.index.MongoIndex;
import com.mongoplus.annotation.index.search.MongoSearchIndex;
import com.mongoplus.annotation.index.vector.MongoVectorField;
import com.mongoplus.annotation.index.vector.MongoVectorIndex;
import com.mongoplus.enums.SearchVectorSimilarity;
import java.util.List;

@CollectionName("catalog")
@MongoSearchIndex(name = "catalog_text", dynamic = true)
@MongoVectorIndex(name = "catalog_vec", fields = {
    @MongoVectorField(fieldName = "embedding", numDimensions = 3,
                      similarity = SearchVectorSimilarity.COSINE)
})
public class IndexedProduct {
    @MongoIndex(name = "sku_unique", unique = true)
    public String sku;
    public String title;
    public List<Double> embedding;
}
