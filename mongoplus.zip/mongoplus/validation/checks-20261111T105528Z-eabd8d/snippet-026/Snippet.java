package skillcheck.c26;
import com.mongoplus.annotation.tenant.IgnoreTenant;

class IgnoreTenantExample { @IgnoreTenant public void maintenance(){} }
