package skillcheck.c57;
import com.mongoplus.annotation.ID;
import com.mongoplus.annotation.collection.CollectionField;
import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.comm.EnumValue;
import com.mongoplus.enums.FieldFill;
import com.mongoplus.handlers.MetaObjectHandler;
import com.mongoplus.model.AutoFillMetaObject;

enum InvoiceState {
    OPEN(1), CLOSED(2);
    @EnumValue private final int code;
    InvoiceState(int code) { this.code = code; }
    public int getCode() { return code; }
}

@CollectionName("invoices")
public class Invoice {
    @ID public String id;
    public InvoiceState state;
    @CollectionField(value = "created_at", fill = FieldFill.INSERT)
    public Long createdAt;
    @CollectionField(value = "updated_at", fill = FieldFill.INSERT_UPDATE)
    public Long updatedAt;
}

class AuditTimes implements MetaObjectHandler {
    public void insertFill(AutoFillMetaObject meta) {
        long now = System.currentTimeMillis();
        meta.fillValue("created_at", now);
        meta.fillValue("updated_at", now);
    }
    public void updateFill(AutoFillMetaObject meta) {
        meta.fillValue("updated_at", System.currentTimeMillis());
    }
}
