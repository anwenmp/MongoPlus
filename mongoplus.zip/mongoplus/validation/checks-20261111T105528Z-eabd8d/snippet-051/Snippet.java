package skillcheck.c51;
import com.mongoplus.handlers.FieldHandler;
import com.mongoplus.handlers.FieldHandlerChain;
import com.mongoplus.mapping.FieldInformation;
import java.util.function.Function;

class TrimField implements FieldHandler {
    public Integer order() { return 10; }
    public Function<FieldInformation,Boolean> activate() {
        return f -> f.getTypeClass() == String.class;
    }
    public Object handler(FieldInformation f) { return handler(f, f.getValue()); }
    public Object handler(FieldInformation f, Object value) {
        return value instanceof String ? ((String)value).trim() : value;
    }
    static void register() { FieldHandlerChain.getInstance().register(new TrimField()); }
}
