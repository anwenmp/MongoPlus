package skillcheck.c56;
import com.mongoplus.annotation.collection.CollectionLogic;
import com.mongoplus.enums.LogicDataType;

class DeletionMarker {
    @CollectionLogic(value = "0", delval = "1", delType = LogicDataType.INTEGER)
    public Integer deleted = 0;
}
