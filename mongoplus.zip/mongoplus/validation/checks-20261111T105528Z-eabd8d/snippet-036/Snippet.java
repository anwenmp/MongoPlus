package skillcheck.c36;
import com.mongoplus.annotation.index.search.MongoSearchIndex;
import com.mongoplus.annotation.index.search.MongoSearchStoredSource;

@MongoSearchIndex(dynamic=true,storedSource=@MongoSearchStoredSource(include={"title"})) class MongoSearchStoredSourceExample {}
