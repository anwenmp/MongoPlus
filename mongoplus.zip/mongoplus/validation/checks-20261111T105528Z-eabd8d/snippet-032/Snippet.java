package skillcheck.c32;
import com.mongoplus.annotation.index.search.MongoSearchField;
import com.mongoplus.annotation.index.search.MongoSearchIndex;

@MongoSearchIndex(name="articles", fields={@MongoSearchField(fieldName="title")}) class MongoSearchIndexExample {}
