package skillcheck.c47;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.ReplaceOptions;
import org.bson.Document;
import java.util.ArrayList;
import java.util.List;

class DriverFallback {
    static List<String> distinct(MongoCollection<Document> collection) {
        return collection.distinct("category", String.class).into(new ArrayList<String>());
    }
    static void replace(MongoCollection<Document> collection, String id, Document replacement) {
        collection.replaceOne(new Document("_id",id),replacement,new ReplaceOptions().upsert(false));
    }
}
