package skillcheck.c50;
import com.mongoplus.aggregate.AggregateWrapper;
import com.mongoplus.aggregate.pipeline.AggregateOperator;
import org.bson.Document;

class PriceExpression {
    static AggregateWrapper projection() {
        return new AggregateWrapper().project(new Document("_id",0)
            .append("remaining",AggregateOperator.subtract("$budget","$spent"))
            .append("label",AggregateOperator.literal("$literal-label")));
    }
}
