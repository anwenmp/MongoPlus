package skillcheck.c33;
import com.mongoplus.annotation.index.search.MongoSearchIndex;
import com.mongoplus.annotation.index.search.MongoSearchIndexes;

@MongoSearchIndexes({@MongoSearchIndex(name="a",dynamic=true),@MongoSearchIndex(name="b",dynamic=true)}) class MongoSearchIndexesExample {}
