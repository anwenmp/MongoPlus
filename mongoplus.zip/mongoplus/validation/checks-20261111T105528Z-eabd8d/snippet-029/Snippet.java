package skillcheck.c29;
import com.mongoplus.annotation.transactional.MongoTransactional;

class MongoTransactionalExample { @MongoTransactional(rollbackFor=Exception.class) public void saveBoth(){} }
