package skillcheck.c3;
import com.mongoplus.annotation.comm.NonNull;

class NonNullExample { @NonNull String value; }
