package skillcheck.c46;
import com.mongoplus.annotation.ID;
import com.mongoplus.annotation.mapper.Mongo;
import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.mapper.MongoMapper;

@CollectionName("orders")
public class OrderRecord {
    @ID private String id;
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
}

@Mongo
interface OrderMapper extends MongoMapper<OrderRecord> {}

class OrderReader {
    private final OrderMapper orders;
    OrderReader(OrderMapper orders) { this.orders = orders; }
    OrderRecord byId(String id) { return orders.getById(id); }
}
