package skillcheck.c7;
import com.mongoplus.annotation.index.MongoCompoundIndex;
import com.mongoplus.annotation.index.MongoCompoundIndexes;

@MongoCompoundIndexes({@MongoCompoundIndex("{\"a\":1}"),@MongoCompoundIndex("{\"b\":1}")}) class MongoCompoundIndexesExample {}
