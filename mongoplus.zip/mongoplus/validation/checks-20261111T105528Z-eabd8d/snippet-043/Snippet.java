package skillcheck.c43;
import com.mongoplus.annotation.index.vector.MongoVectorField;
import com.mongoplus.annotation.index.vector.MongoVectorIndex;
import com.mongoplus.annotation.index.vector.MongoVectorStoredSource;
import com.mongoplus.enums.SearchVectorSimilarity;

@MongoVectorIndex(fields={@MongoVectorField(fieldName="embedding",numDimensions=3,similarity=SearchVectorSimilarity.COSINE)},storedSource=@MongoVectorStoredSource(include={"title"})) class MongoVectorStoredSourceExample {}
