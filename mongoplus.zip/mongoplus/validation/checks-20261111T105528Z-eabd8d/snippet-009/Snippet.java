package skillcheck.c9;
import com.mongoplus.annotation.index.MongoHashIndex;

class MongoHashIndexExample { @MongoHashIndex String key; }
