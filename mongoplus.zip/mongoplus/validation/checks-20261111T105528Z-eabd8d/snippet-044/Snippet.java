package skillcheck.c44;
import com.mongodb.client.model.Variable;
import com.mongoplus.aggregate.AggregateWrapper;
import com.mongoplus.aggregate.pipeline.AggregateOperator;
import com.mongoplus.conditions.query.QueryWrapper;
import com.mongoplus.mapper.MongoMapper;
import com.mongoplus.toolkit.Filters;
import java.util.Collections;
import java.util.List;
import org.bson.Document;

class QuoteJoin {
    static AggregateWrapper pipeline(String foreignCollection) {
        AggregateWrapper offers = new AggregateWrapper()
            .match(new QueryWrapper<>().eq("active", true))
            .match(Filters.expr(AggregateOperator.eq("$customer", "$$buyer")))
            .sortSpecification(new Document("fee", -1).append("_id", 1)).limit(1);
        return new AggregateWrapper()
            .match(new QueryWrapper<>().eq("state", "OPEN"))
            .lookup(foreignCollection, Collections.singletonList(
                new Variable<String>("buyer", "$customer")), offers, "quotes")
            .sortSpecification(new Document("_id", 1));
    }

    static <T> List<Document> list(MongoMapper<T> orders, String offersCollection) {
        return orders.list(pipeline(offersCollection), Document.class);
    }
}
