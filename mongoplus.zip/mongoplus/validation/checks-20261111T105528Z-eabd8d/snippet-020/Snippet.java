package skillcheck.c20;
import com.mongoplus.annotation.collection.ExtraFields;

class ExtraFieldsExample { @ExtraFields java.util.Map<String,Object> extra; }
