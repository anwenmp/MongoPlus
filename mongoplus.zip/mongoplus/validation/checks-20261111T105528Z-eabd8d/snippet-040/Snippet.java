package skillcheck.c40;
import com.mongoplus.annotation.index.vector.MongoVectorField;
import com.mongoplus.annotation.index.vector.MongoVectorHnswOptions;
import com.mongoplus.annotation.index.vector.MongoVectorIndex;
import com.mongoplus.enums.SearchVectorSimilarity;

@MongoVectorIndex(fields={@MongoVectorField(fieldName="embedding",numDimensions=3,similarity=SearchVectorSimilarity.COSINE,hnswOptions=@MongoVectorHnswOptions(maxEdges=32,numEdgeCandidates=200))}) class MongoVectorHnswOptionsExample {}
