package skillcheck.c18;
import com.mongoplus.annotation.ID;
import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.collection.DBRef;

@CollectionName("customers") class DBRefTarget { @ID String id; }
class DBRefExample { @DBRef DBRefTarget customer; }
