package skillcheck.c15;
import com.mongoplus.annotation.collection.CollectionField;

class CollectionFieldExample { @CollectionField(value="display_name", ignoreNull=false) String name; }
