package skillcheck.c31;
import com.mongoplus.annotation.index.search.MongoSearchField;
import com.mongoplus.annotation.index.search.MongoSearchFields;
import com.mongoplus.annotation.index.search.MongoSearchIndex;
import com.mongoplus.enums.SearchFieldType;

@MongoSearchIndex(name="articles") class MongoSearchFieldsExample { @MongoSearchFields({@MongoSearchField(type=SearchFieldType.STRING),@MongoSearchField(type=SearchFieldType.TOKEN)}) String title; }
