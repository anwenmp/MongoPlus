package skillcheck.c14;
import com.mongoplus.annotation.MongoMapperScan;

@MongoMapperScan("example.mapper") class MongoMapperScanExample {}
