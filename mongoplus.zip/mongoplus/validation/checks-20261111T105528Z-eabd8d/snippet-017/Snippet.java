package skillcheck.c17;
import com.mongoplus.annotation.collection.CollectionName;

@CollectionName("orders") class CollectionNameExample { String title; }
