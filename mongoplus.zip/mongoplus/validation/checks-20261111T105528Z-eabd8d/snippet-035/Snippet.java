package skillcheck.c35;
import com.mongoplus.annotation.index.search.MongoSearchIndex;
import com.mongoplus.annotation.index.search.MongoSearchIndexes;
import com.mongoplus.annotation.index.search.MongoSearchSort;
import com.mongoplus.annotation.index.search.MongoSearchSorts;

@MongoSearchIndexes({@MongoSearchIndex(name="a",dynamic=true),@MongoSearchIndex(name="b",dynamic=true)}) class MongoSearchSortsExample { @MongoSearchSorts({@MongoSearchSort(name="a"),@MongoSearchSort(name="b")}) String title; }
