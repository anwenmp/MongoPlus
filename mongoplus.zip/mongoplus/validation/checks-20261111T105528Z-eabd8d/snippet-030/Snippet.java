package skillcheck.c30;
import com.mongoplus.annotation.index.search.MongoSearchField;
import com.mongoplus.annotation.index.search.MongoSearchIndex;

@MongoSearchIndex(name="articles") class MongoSearchFieldExample { @MongoSearchField String title; }
