package skillcheck.c25;
import com.mongoplus.annotation.logice.IgnoreLogic;

@IgnoreLogic class IgnoreLogicExample { public void maintenance(){} }
