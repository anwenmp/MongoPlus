package skillcheck.c55;
import com.mongoplus.handlers.TenantHandler;
import java.util.function.Supplier;
import org.bson.BsonString;
import org.bson.BsonValue;

class RequestTenant implements TenantHandler {
    private final Supplier<String> identity;
    RequestTenant(Supplier<String> identity) { this.identity = identity; }
    public BsonValue getTenantId() {
        String id = identity.get();
        if (id == null || id.trim().isEmpty()) throw new SecurityException("Tenant required");
        return new BsonString(id);
    }
}
