package skillcheck.c1;
import com.mongoplus.annotation.comm.Desensitization;
import com.mongoplus.enums.DesensitizationTypeEnum;

class DesensitizationExample { @Desensitization(type=DesensitizationTypeEnum.MOBILE_PHONE) String phone; }
