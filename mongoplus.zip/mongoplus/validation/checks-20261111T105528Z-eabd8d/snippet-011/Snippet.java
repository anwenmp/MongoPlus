package skillcheck.c11;
import com.mongoplus.annotation.index.MongoIndexDs;

@MongoIndexDs(dataSource="archive") class MongoIndexDsExample {}
