package skillcheck.c27;
import com.mongoplus.annotation.datasource.MongoDs;

@MongoDs("archive") class MongoDsExample { void query(){} }
