package skillcheck.c10;
import com.mongoplus.annotation.index.MongoIndex;

class MongoIndexExample { @MongoIndex(name="email_unique", unique=true) String email; }
