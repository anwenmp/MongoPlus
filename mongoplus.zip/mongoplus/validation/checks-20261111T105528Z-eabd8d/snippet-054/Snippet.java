package skillcheck.c54;
import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.UpdateOptions;
import com.mongoplus.enums.ExecuteMethodEnum;
import com.mongoplus.interceptor.Interceptor;
import com.mongoplus.model.QueryParam;
import com.mongoplus.model.MutablePair;
import com.mongoplus.toolkit.Filters;
import java.util.Collection;
import java.util.Objects;
import java.util.function.Supplier;
import org.bson.Document;
import org.bson.BsonDocument;
import org.bson.conversions.Bson;

class DepartmentReads implements Interceptor {
    private final String collectionName;
    private final Supplier<Collection<String>> allowed;
    DepartmentReads(String collectionName, Supplier<Collection<String>> allowed) {
        this.collectionName = collectionName;
        this.allowed = allowed;
    }
    private boolean protects(MongoCollection<Document> c) {
        return collectionName.equals(c.getNamespace().getCollectionName());
    }
    public void beforeExecute(ExecuteMethodEnum op, Object[] args, MongoCollection<Document> c) {
        if (!protects(c) || op == ExecuteMethodEnum.QUERY) return;
        if (op != ExecuteMethodEnum.UPDATE_ONE) throw new SecurityException("Unsupported operation");
        UpdateOptions options = (UpdateOptions) args[1];
        if (options != null && options.isUpsert()) throw new SecurityException("Upsert denied");
    }
    private Bson restricted(Bson original) {
        Bson scope = Filters.in("department_id", Objects.requireNonNull(allowed.get()));
        return original == null ? scope : Filters.and(original, scope);
    }
    public QueryParam executeQuery(Bson original, BasicDBObject projection,
                                   BasicDBObject sort, MongoCollection<Document> c) {
        if (!protects(c)) return new QueryParam(original, projection, sort);
        return new QueryParam(restricted(original), projection, sort);
    }
    public MutablePair<Bson,Bson> executeUpdate(MutablePair<Bson,Bson> pair,
                                                MongoCollection<Document> c) {
        if (!protects(c)) return pair;
        BsonDocument update = pair.getRight().toBsonDocument(BsonDocument.class, c.getCodecRegistry());
        if (update.size() != 1 || !update.isDocument("$set")) throw new SecurityException("Invalid update");
        BsonDocument set = update.getDocument("$set");
        if (set.size() != 1 || !set.isString("note")) throw new SecurityException("Only note may change");
        return new MutablePair<>(restricted(pair.getLeft()), pair.getRight());
    }
}
