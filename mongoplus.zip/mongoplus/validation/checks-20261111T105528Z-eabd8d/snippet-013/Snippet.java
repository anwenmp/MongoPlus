package skillcheck.c13;
import com.mongoplus.annotation.mapper.Mongo;

@Mongo interface MongoExample extends com.mongoplus.mapper.MongoMapper<MongoEntityExample> {}
class MongoEntityExample {}
