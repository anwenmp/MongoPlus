package skillcheck.c48;
import com.mongoplus.listener.Listener;
import com.mongoplus.model.command.CommandFailed;
import com.mongoplus.model.command.CommandStarted;
import com.mongoplus.model.command.CommandSucceeded;
import java.util.function.BiConsumer;

class CommandAlarm implements Listener {
    private final BiConsumer<String, String> record;
    CommandAlarm(BiConsumer<String, String> record) { this.record = record; }
    public void commandStarted(CommandStarted event) {}
    public void commandSucceeded(CommandSucceeded event) {}
    public void commandFailed(CommandFailed event) {
        record.accept(event.getCommandName(), event.getThrowable().getClass().getSimpleName());
    }
    public int getOrder() { return LOWEST_PRECEDENCE; }
}
