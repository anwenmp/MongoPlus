package skillcheck.c23;
import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.collection.TimeSeries;

@CollectionName("measurements") @TimeSeries(timeField="time", metaField="sensor") class TimeSeriesExample { java.util.Date time; String sensor; }
