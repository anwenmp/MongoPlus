package skillcheck.c4;
import com.mongoplus.annotation.comm.Nullable;

class NullableExample { @Nullable String value; }
