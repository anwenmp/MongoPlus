package skillcheck.c53;
import com.mongoplus.config.Configuration;
import com.mongoplus.mapper.BaseMapper;

class CoreSetup {
    static BaseMapper create(String uri, String database) {
        return Configuration.builder().connection(uri).database(database)
            .banner(false).getBaseMapper();
    }
}
