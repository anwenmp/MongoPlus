package skillcheck.c6;
import com.mongoplus.annotation.index.MongoCompoundIndex;

@MongoCompoundIndex(value="{\"tenant\":1,\"created_at\":-1}", name="tenant_time") class MongoCompoundIndexExample {}
