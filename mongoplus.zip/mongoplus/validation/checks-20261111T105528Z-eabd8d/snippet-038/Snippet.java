package skillcheck.c38;
import com.mongoplus.annotation.index.vector.MongoVectorField;
import com.mongoplus.annotation.index.vector.MongoVectorIndex;
import com.mongoplus.enums.SearchVectorSimilarity;

@MongoVectorIndex(name="vec") class MongoVectorFieldExample { @MongoVectorField(numDimensions=3,similarity=SearchVectorSimilarity.COSINE) java.util.List<Double> embedding; }
