package skillcheck.c5;
import com.mongoplus.annotation.SensitiveWord;

class SensitiveWordExample { @SensitiveWord String body; }
