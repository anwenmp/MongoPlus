package skillcheck.c24;
import com.mongoplus.annotation.collection.Version;

class VersionExample { @Version Integer version; }
