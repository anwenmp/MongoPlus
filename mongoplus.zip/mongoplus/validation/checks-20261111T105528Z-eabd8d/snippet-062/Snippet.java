package skillcheck.c62;
import com.mongoplus.handlers.CollectionNameHandler;

class OrderRouting {
    static CollectionNameHandler forArchive() {
        return (operation, args, ns) -> "orders".equals(ns.getCollectionName())
            ? "orders_archive" : ns.getCollectionName();
    }
}
