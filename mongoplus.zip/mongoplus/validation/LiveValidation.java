import com.mongodb.*;
import com.mongodb.client.*;
import com.mongodb.client.model.*;
import com.mongodb.event.*;
import com.mongoplus.aggregate.AggregateWrapper;
import com.mongoplus.aggregate.pipeline.Accumulators;
import com.mongoplus.annotation.ID;
import com.mongoplus.annotation.collection.*;
import com.mongoplus.annotation.comm.*;
import com.mongoplus.cache.global.HandlerCache;
import com.mongoplus.conditions.query.QueryWrapper;
import com.mongoplus.conditions.update.UpdateWrapper;
import com.mongoplus.config.Configuration;
import com.mongoplus.enums.*;
import com.mongoplus.handlers.*;
import com.mongoplus.handlers.read.FieldBindHandler;
import com.mongoplus.interceptor.business.OptimisticLockerInterceptor;
import com.mongoplus.manager.*;
import com.mongoplus.mapper.*;
import com.mongoplus.mapping.*;
import com.mongoplus.model.*;
import com.mongoplus.parser.index.Resolver;
import com.mongoplus.registry.MongoEntityMappingRegistry;
import com.mongoplus.toolkit.*;
import org.bson.*;
import org.bson.conversions.Bson;
import org.yaml.snakeyaml.Yaml;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.function.*;
import java.util.function.Function;
import java.util.stream.*;

/** Bounded, dedicated-collection experiments. Connection configuration is read, never copied/logged. */
public class LiveValidation {
    static final List<Document> cases=new ArrayList<>(),commands=new ArrayList<>();
    static final List<String> owned=new ArrayList<>();
    static final String prefix="skill_cov_"+UUID.randomUUID().toString().replace("-","").substring(0,12)+"_";
    static MongoClient client,independent;static MongoDatabase db,nativeDb;static BaseMapper mapper;static String database,current,phase;
    static String name(String suffix){String n=prefix+suffix+"_"+owned.size();owned.add(n);return n;}
    static Document doc(String s){return Document.parse(s);}
    static void require(boolean b,String msg){if(!b)throw new AssertionError(msg);}
    static void same(Object a,Object b){require(Objects.equals(a,b),"Complete results differ: "+a+" / "+b);}
    static List<Document> canonical(List<Document> rows){return rows.stream().sorted(Comparator.comparing(Document::toJson)).collect(Collectors.toList());}
    interface Checked { void run()throws Exception; }
    static void test(String label,String api,Checked action){
        current=label;casesResult=null;int start=commands.size();String category=label.startsWith("annotation-parser-")?"PARSE":label.startsWith("deployment-probe-")?"PREREQUISITE":"LIVE";
        Document item=new Document("case",label).append("api",api).append("category",category);
        try {action.run();item.append("status",category+"_PASS");}
        catch(Throwable e){item.append("status",e instanceof MongoCommandException&&((MongoCommandException)e).getErrorCode()==31082&&category.equals("PREREQUISITE")?"NOT_RUN":"CONTRACT_UNRESOLVED").append("exception",e.getClass().getName());
            if(e instanceof MongoCommandException)item.append("serverCode",((MongoCommandException)e).getErrorCode());
            if(e instanceof MongoCommandException)item.append("serverMessage",((MongoCommandException)e).getErrorMessage());
            if(e instanceof com.mongoplus.domain.MongoPlusException)item.append("frameworkMessage",e.getMessage());
            // Data-only assertion messages contain our generated fixture, never a URI.
            if(e instanceof AssertionError)item.append("assertion",e.getMessage());
        }
        if(casesResult!=null)item.append("results",casesResult);
        item.append("commands",new ArrayList<>(commands.subList(start,commands.size())));cases.add(item);
        System.out.println(label+" "+item.getString("status"));
    }
    static CommandListener listener(){return new CommandListener(){
        public void commandStarted(CommandStartedEvent e){
            if(e.getDatabaseName().equals(database)&&e.getCommand().toJson().contains(prefix))
                commands.add(new Document("case",current).append("phase",phase).append("name",e.getCommandName()).append("command",Document.parse(e.getCommand().toJson())));
        }
    };}
    static void reset(String collection){
        MongoCollection<Document> c=nativeDb.getCollection(collection);c.deleteMany(new Document());
        c.insertMany(Arrays.asList(doc("{_id:1,category:'A',v:10,items:[{sku:'X',qty:1},{sku:'Y',qty:3}],tags:['a','b']}"),doc("{_id:2,category:'A',v:20,items:[{sku:'X',qty:3}],tags:['a']}"),doc("{_id:3,category:'B',v:30,items:[{sku:'Z',qty:4}],tags:[]}")));
    }
    static void pipeline(String label,AggregateWrapper wrapper,Bson... nativePipeline){
        test(label,"AggregateWrapper."+label,()->{
            String c=name("agg"+cases.size());reset(c);phase="mongoplus";
            List<Document> actual=mapper.aggregateList(database,c,wrapper,Document.class);
            phase="native";List<Document> expected=nativeDb.getCollection(c).aggregate(Arrays.asList(nativePipeline)).into(new ArrayList<>());
            same(canonical(actual),canonical(expected));
            require(commands.stream().anyMatch(x->label.equals(x.getString("case"))&&"mongoplus".equals(x.getString("phase"))&&"aggregate".equals(x.getString("name"))),"No actual MongoPlus aggregate command");
            Document sent=commands.stream().filter(x->label.equals(x.getString("case"))&&"mongoplus".equals(x.getString("phase"))&&"aggregate".equals(x.getString("name"))).reduce((x,y)->y).get().get("command",Document.class);
            Document control=commands.stream().filter(x->label.equals(x.getString("case"))&&"native".equals(x.getString("phase"))&&"aggregate".equals(x.getString("name"))).reduce((x,y)->y).get().get("command",Document.class);
            same(sent.get("pipeline"),control.get("pipeline"));
            casesResult=new Document("mongoplus",actual).append("native",expected);
        });
        casesResult=null;
    }
    static Document casesResult;
    @CollectionName("ignored_entity_name")
    public static class Mapped {
        @ID public String id;
        @CollectionField("display_name") public String name;
        @CollectionField(ignoreNull=false) public String empty;
        @CollectionField(exist=false) public String ignored;
        @FieldEncrypt(algorithm=AlgorithmEnum.BASE64) public String secret;
        @Desensitization(type=DesensitizationTypeEnum.MOBILE_PHONE) public String phone;
        public State state;
        @ExtraFields public Map<String,Object> extra;
    }
    public enum State { OPEN(1);@EnumValue public final int code;State(int v){code=v;} }
    public static class Chained { @ID public String id;public String value; }
    public static class Dict { @ID public String id;@FieldBind(type="status",target="label") public String status;@CollectionField(exist=false) public String label; }
    public static class DictCamel { @ID public String id;@FieldBind(type="status",target="statusName") public String status;@CollectionField(exist=false) public String statusName; }
    public static class Versioned { @ID public String id;@Version public Integer version;public String title; }
    static final class TargetAnnotationLoader {
        static void run()throws Exception {
            String[] names={"MongoCompoundIndex","MongoCompoundIndexes","MongoGeoIndex","MongoHashIndex","MongoIndex","MongoIndexDs","MongoTextIndex","MongoSearchIndex","MongoSearchIndexes","MongoSearchField","MongoSearchFields","MongoSearchSort","MongoSearchSorts","MongoSearchStoredSource","MongoSearchSynonym","MongoVectorIndex","MongoVectorIndexes","MongoVectorField","MongoVectorFields","MongoVectorHnswOptions","MongoVectorStoredSource"};
            for(String name:names)test("annotation-parser-"+name,"Resolver.resolve("+name+"Example)",()->{
                Class<?> clazz=Class.forName(name+"Example");IndexMetaObject meta=new Resolver().resolve(clazz);
                if(name.equals("MongoIndexDs"))same(meta.getDataSource(),"archive");
                else require(!meta.getIndexModels().isEmpty()||!meta.getSearchIndexModels().isEmpty(),"No index model produced");
                Document definitions=new Document("ordinary",meta.getIndexModels().stream().map(m->m.getKeys().toBsonDocument(Document.class,MongoClientSettings.getDefaultCodecRegistry()).toJson()).collect(Collectors.toList())).append("search",meta.getSearchIndexModels().stream().map(m->m.getDefinition().toBsonDocument(Document.class,MongoClientSettings.getDefaultCodecRegistry()).toJson()).collect(Collectors.toList()));
                casesResult=definitions;
            });
        }
    }
    @SuppressWarnings("unchecked")
    static void connect(Path file)throws Exception {
        Map<String,Object> config=new Yaml().load(Files.newInputStream(file));Map<String,Object> root=(Map<String,Object>)config.get("mongo-plus");Map<String,Object> props=(Map<String,Object>)((Map<String,Object>)root.get("data")).get("mongodb");
        BaseProperty property=new BaseProperty();
        // Bind only known setters; never serialize this object.
        for(java.lang.reflect.Method method:BaseProperty.class.getMethods()){
            if(!method.getName().startsWith("set")||method.getParameterCount()!=1)continue;
            String n=method.getName().substring(3);String key=Character.toLowerCase(n.charAt(0))+n.substring(1);key=key.replaceAll("([a-z0-9])([A-Z])","$1-$2").toLowerCase(Locale.ROOT);
            Object v=props.get(key);if(v==null)continue;Class<?> type=method.getParameterTypes()[0];
            if(type==String.class)v=v.toString();else if(type==Integer.class||type==int.class)v=Integer.valueOf(v.toString());else if(type==Boolean.class||type==boolean.class)v=Boolean.valueOf(v.toString());
            method.invoke(property,v);
        }
        database=property.getDatabase().split(",")[0];property.setDatabase(database);
        String uri=new UrlJoint(property).jointMongoUrl();MongoClientSettings settings=MongoClientSettings.builder().applyConnectionString(new ConnectionString(uri)).applyToClusterSettings(b->b.serverSelectionTimeout(15,TimeUnit.SECONDS)).addCommandListener(listener()).build();
        client=MongoClients.create(settings);independent=MongoClients.create(settings);db=client.getDatabase(database);nativeDb=independent.getDatabase(database);
        db.runCommand(new Document("ping",1));
        mapper=Configuration.builder().connection(uri).database(database).mongoClient(client).banner(false).getBaseMapper();
    }
    public static void main(String[] args)throws Exception {
        Path output=Paths.get(args[1]);Files.createDirectories(output);
        try {
            connect(Paths.get(args[0]));String version=db.runCommand(new Document("buildInfo",1)).getString("version");
            Document m=doc("{v:{$gte:20}}");pipeline("match-Bson-body",new AggregateWrapper().match(m),new Document("$match",m));
            Document p=doc("{_id:0,v:1}");pipeline("project-Bson-body",new AggregateWrapper().project(p),new Document("$project",p));
            Document a=doc("{double:{$multiply:['$v',2]}}");pipeline("addFields-Bson-body",new AggregateWrapper().addFields(a),new Document("$addFields",a));
            pipeline("set-Bson-body",new AggregateWrapper().set(a),new Document("$set",a));
            Document bucket=doc("{groupBy:'$v',boundaries:[0,20,40],output:{n:{$sum:1}}}");pipeline("bucket-Bson-body",new AggregateWrapper().bucket(bucket),new Document("$bucket",bucket));
            Document ba=doc("{groupBy:'$v',buckets:2}");pipeline("bucketAuto-Bson-body",new AggregateWrapper().bucketAuto(ba),new Document("$bucketAuto",ba));
            Document sort=doc("{$sort:{v:-1}}");pipeline("sort-Bson-full-stage",new AggregateWrapper().sort(sort),sort);
            pipeline("sortSpecification-body",new AggregateWrapper().sortSpecification(doc("{v:-1}")),sort);
            pipeline("sort-String",new AggregateWrapper().sort("v",-1),sort);
            Document group=doc("{$group:{_id:'$category',total:{$sum:'$v'}}}");pipeline("group-Bson-full-stage",new AggregateWrapper().group(group),group);
            pipeline("group-accumulator",new AggregateWrapper().group("$category",Accumulators.sum("total","$v")),group);
            Document facet=doc("{$facet:{small:[{$match:{v:{$lt:20}}}],all:[{$count:'n'}]}}");pipeline("facet-Bson-full-stage",new AggregateWrapper().facet(facet),facet);
            Document unwind=doc("{$unwind:'$tags'}");pipeline("unwind-Bson-full-stage",new AggregateWrapper().unwind(unwind),unwind);
            Document replace=doc("{$replaceRoot:{newRoot:{value:'$v'}}}");pipeline("replaceRoot-Bson-full-stage",new AggregateWrapper().replaceRoot((Bson)replace),replace);
            pipeline("replaceRoot-Document-expression",new AggregateWrapper().replaceRoot(doc("{value:'$v'}")),replace);
            Document rw=doc("{$replaceWith:{value:'$v'}}");pipeline("replaceWith-Bson-full-stage",new AggregateWrapper().replaceWith((Bson)rw),rw);
            pipeline("replaceWith-Document-expression",new AggregateWrapper().replaceWith(doc("{value:'$v'}")),rw);
            Document sample=doc("{$sample:{size:3}}");pipeline("sample-Bson-full-stage",new AggregateWrapper().sample(sample),sample);
            Document window=doc("{$setWindowFields:{partitionBy:'$category',sortBy:{v:1},output:{total:{$sum:'$v',window:{documents:['unbounded','current']}}}}}");pipeline("window-Bson-full-stage",new AggregateWrapper().setWindowFields(window),window);
            Document densify=doc("{$densify:{field:'v',range:{step:5,bounds:'full'}}}");pipeline("densify-Bson-full-stage",new AggregateWrapper().densify(densify),densify);
            Document fill=doc("{$fill:{output:{missing:{value:7}}}}");pipeline("fill-Bson-full-stage",new AggregateWrapper().fill(fill),fill);
            Document unset=doc("{$unset:['items','tags']}");pipeline("unset-Bson-full-stage",new AggregateWrapper().unset(unset),unset);
            pipeline("skip-limit",new AggregateWrapper().sortSpecification(doc("{_id:1}")).skip(1).limit(1),doc("{$sort:{_id:1}}"),doc("{$skip:1}"),doc("{$limit:1}"));
            pipeline("sortByCount",new AggregateWrapper().sortByCount("$category"),doc("{$sortByCount:'$category'}"));
            String foreign=name("foreign");reset(foreign);
            Document lookup=new Document("$lookup",new Document("from",foreign).append("localField","_id").append("foreignField","_id").append("as","joined"));
            pipeline("lookup-Bson-full-stage",new AggregateWrapper().lookup(lookup),lookup);
            pipeline("lookup-four-String",new AggregateWrapper().lookup(foreign,"_id","_id","joined"),lookup);
            Document union=new Document("$unionWith",new Document("coll",foreign).append("pipeline",Collections.singletonList(doc("{$match:{v:{$gt:20}}}"))));pipeline("unionWith-Bson-full-stage",new AggregateWrapper().unionWith(union),union);
            test("query-same-array-element","BaseMapper.list + QueryWrapper.elemMatch(String,Wrapper)",()->{
                String c=name("query");reset(c);QueryWrapper<Object>w=new QueryWrapper<>().elemMatch("items",new QueryWrapper<>().eq("sku","X").gte("qty",2));
                phase="mongoplus";List<Document>actual=mapper.list(database,c,w,Document.class);phase="native";List<Document>expected=nativeDb.getCollection(c).find(doc("{items:{$elemMatch:{sku:'X',qty:{$gte:2}}}}}")).into(new ArrayList<>());same(actual,expected);
                require(actual.size()==1&&actual.get(0).getInteger("_id")==2,"Wrong same-element match");
            });
            test("regex-explicit-case-sensitive","QueryWrapper.regex(String,Object,RegexOptions)",()->{
                String c=name("regex");nativeDb.getCollection(c).insertMany(Arrays.asList(doc("{_id:1,title:'Alpha'}"),doc("{_id:2,title:'alpha'}"),doc("{_id:3,title:'Beta'}")));
                phase="mongoplus";List<Document> actual=mapper.list(database,c,new QueryWrapper<>().regex("title","^A",RegexOptions.UNICODE),Document.class);
                phase="native";List<Document>expected=nativeDb.getCollection(c).find(doc("{title:{$regex:'^A',$options:'u'}}")).into(new ArrayList<>());same(actual,expected);same(actual.size(),1);
            });
            test("projection-sort","QueryWrapper.projectDisplay + orderByDesc",()->{
                String c=name("project");reset(c);phase="mongoplus";List<Document> actual=mapper.list(database,c,new QueryWrapper<>().gte("v",20).orderByDesc("v").projectDisplay("_id","v"),Document.class);
                phase="native";List<Document>expected=nativeDb.getCollection(c).find(doc("{v:{$gte:20}}")).sort(doc("{v:-1}")).projection(doc("{_id:1,v:1}")).into(new ArrayList<>());same(actual,expected);
            });
            test("update-CAS-single","BaseMapper.updateOne(UpdateWrapper)",()->{
                String c=name("cas"),n=name("cas_native");reset(c);reset(n);UpdateWrapper<Object>w=new UpdateWrapper<>().eq("_id",1).eq("v",10).set("category","WIN").inc("v",1);
                phase="mongoplus";require(mapper.updateOne(database,c,w,null),"First write failed");require(!mapper.updateOne(database,c,w,null),"Stale write won");
                phase="native";nativeDb.getCollection(n).updateOne(doc("{_id:1,v:10}"),doc("{$set:{category:'WIN'},$inc:{v:1}}"));same(nativeDb.getCollection(c).find().into(new ArrayList<>()),nativeDb.getCollection(n).find().into(new ArrayList<>()));
            });
            for(String kind:Arrays.asList("value","wrapper-custom"))test("pull-"+kind,"UpdateWrapper.pull",()->{
                String c=name("pull"),n=name("pull_native");reset(c);reset(n);UpdateWrapper<Object>w=new UpdateWrapper<>();w.eq("_id",2);
                if(kind.equals("value"))w.pull("items",doc("{sku:'X',qty:{$gte:2}}"));else w.pull(new QueryWrapper<>().custom(doc("{items:{sku:'X',qty:{$gte:2}}}")));
                phase="mongoplus";mapper.updateOne(database,c,w,null);phase="native";nativeDb.getCollection(n).updateOne(doc("{_id:2}"),doc("{$pull:{items:{sku:'X',qty:{$gte:2}}}}"));same(nativeDb.getCollection(c).find().into(new ArrayList<>()),nativeDb.getCollection(n).find().into(new ArrayList<>()));
            });
            test("mapped-annotations-roundtrip","BaseMapper.save/list + mapping annotations",()->{
                String c=name("mapped");Mapped entity=new Mapped();entity.id="map-id";entity.name="Alice";entity.secret="secret";entity.phone="13812345678";entity.state=State.OPEN;entity.ignored="no";
                phase="mongoplus";require(mapper.save(database,c,entity),"Save failed");phase="native";Document raw=nativeDb.getCollection(c).find().first();same(raw.getString("display_name"),"Alice");require(raw.containsKey("empty")&&!raw.containsKey("ignored"),"Field/null mapping wrong");same(raw.getString("secret"),Base64.getEncoder().encodeToString("secret".getBytes("UTF-8")));same(raw.getInteger("state"),1);nativeDb.getCollection(c).updateOne(new Document("_id","map-id"),new Document("$set",new Document("unknown","extra")));
                phase="mongoplus";Mapped read=mapper.list(database,c,Mapped.class).get(0);same(read.secret,"secret");same(read.phone,"138****5678");same(read.state,State.OPEN);same(read.extra.get("unknown"),"extra");
            });
            test("field-chain-current-value","FieldHandlerChain + Mapper.save",()->{
                FieldHandler first=new FieldHandler(){public Integer order(){return 10;}public Function<FieldInformation,Boolean>activate(){return f->f.getBelongClass()==Chained.class&&f.getName().equals("value");}public Object handler(FieldInformation f){return handler(f,f.getValue());}public Object handler(FieldInformation f,Object v){return v+"-one";}};
                FieldHandler second=new FieldHandler(){public Integer order(){return 20;}public Function<FieldInformation,Boolean>activate(){return first.activate();}public Object handler(FieldInformation f){return handler(f,f.getValue());}public Object handler(FieldInformation f,Object v){return v+"-two";}};
                FieldHandlerChain.getInstance().registerAll(Arrays.asList(second,first));try{String c=name("chain");Chained x=new Chained();x.id="chain-id";x.value="start";phase="mongoplus";mapper.save(database,c,x);phase="native";same(nativeDb.getCollection(c).find().first().getString("value"),"start-one-two");}finally{FieldHandlerChain.getInstance().remove(first);FieldHandlerChain.getInstance().remove(second);}
            });
            test("fieldbind-explicit-registration","HandlerCache.addReadHandler(new FieldBindHandler)",()->{
                FieldBindHandler handler=new FieldBindHandler((annotation,value,target)->target.setValue("Name-"+value));HandlerCache.addReadHandler(handler);
                try{String c=name("dict");nativeDb.getCollection(c).insertOne(doc("{_id:'dict-id',status:'A'}"));phase="mongoplus";Dict x=mapper.list(database,c,Dict.class).get(0);same(x.label,"Name-A");}finally{HandlerCache.getReadHandler().remove(handler);}
            });
            test("fieldbind-camel-target","FieldBind.target(statusName) + ReadHandler",()->{
                FieldBindHandler handler=new FieldBindHandler((annotation,value,target)->target.setValue("Name-"+value));HandlerCache.addReadHandler(handler);
                try{String c=name("dictcamel");nativeDb.getCollection(c).insertOne(doc("{_id:'dict-id',status:'A'}"));phase="mongoplus";DictCamel x=mapper.list(database,c,DictCamel.class).get(0);same(x.statusName,"Name-A");}finally{HandlerCache.getReadHandler().remove(handler);}
            });
            test("ordinary-index-unique","Resolver + BaseMapper.createIndexes",()->{
                String c=name("index");IndexMetaObject meta=new Resolver().resolve(Class.forName("MongoIndexExample"));phase="mongoplus";mapper.createIndexes(database,c,meta.getIndexModels());phase="native";List<Document>indexes=nativeDb.getCollection(c).listIndexes().into(new ArrayList<>());require(indexes.stream().anyMatch(x->Boolean.TRUE.equals(x.getBoolean("unique"))),"Unique option lost");nativeDb.getCollection(c).insertOne(doc("{email:'x'}"));boolean duplicate=false;try{nativeDb.getCollection(c).insertOne(doc("{email:'x'}"));}catch(MongoWriteException e){duplicate=e.getError().getCode()==11000;}require(duplicate,"Unique constraint absent");
            });
            test("transaction-commit","MongoTransactionalManager + Mapper",()->{
                String c=name("commit");nativeDb.createCollection(c);try{MongoTransactionalManager.startTransaction();phase="mongoplus";mapper.save(database,c,new Document("_id","tx"));require(nativeDb.getCollection(c).countDocuments()==0,"Uncommitted visible");MongoTransactionalManager.commitTransaction();same(nativeDb.getCollection(c).countDocuments(),1L);}finally{MongoTransactionalManager.closeSession();}
            });
            test("transaction-rollback","MongoTransactionalManager + Mapper",()->{
                String c=name("rollback");nativeDb.createCollection(c);try{MongoTransactionalManager.startTransaction();phase="mongoplus";mapper.save(database,c,new Document("_id","tx"));MongoTransactionalManager.rollbackTransaction();same(nativeDb.getCollection(c).countDocuments(),0L);}finally{MongoTransactionalManager.closeSession();}
            });
            for(String type:Arrays.asList("search","vectorSearch"))test("deployment-probe-"+type,"Driver listSearchIndexes prerequisite",()->{
                String c=name("probe");nativeDb.createCollection(c);phase="prerequisite";nativeDb.getCollection(c).listSearchIndexes().into(new ArrayList<>());
            });
            TargetAnnotationLoader.run();
            Files.write(output.resolve("environment.json"),new Document("jdk",System.getProperty("java.version")).append("mongodb",version).append("collectionPrefix",prefix).toJson().getBytes("UTF-8"));
        }catch(Throwable e){
            cases.add(new Document("case","infrastructure").append("status","INFRA_FAIL").append("exception",e.getClass().getName()));
            System.out.println("Infrastructure failure: "+e.getClass().getName());
        }finally{
            List<String> cleanupFailures=new ArrayList<>();
            if(independent!=null){for(String c:owned){if(!c.startsWith(prefix))throw new IllegalStateException("Foreign cleanup target");try{nativeDb.getCollection(c).drop();}catch(Exception e){cleanupFailures.add(c+":"+e.getClass().getName());}}
                try{for(String c:nativeDb.listCollectionNames())if(c.startsWith(prefix))cleanupFailures.add(c);}catch(Exception e){cleanupFailures.add(e.getClass().getName());}independent.close();}
            if(client!=null)client.close();
            Document report=new Document("cases",cases).append("createdCollections",owned).append("commands",commands.size()).append("cleanupFailures",cleanupFailures);Files.write(output.resolve("results.json"),report.toJson().getBytes("UTF-8"));
        }
    }
}
