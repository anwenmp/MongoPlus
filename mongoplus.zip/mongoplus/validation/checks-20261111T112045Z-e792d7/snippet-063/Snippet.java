package skillcheck.c63;
import com.mongoplus.mapper.MongoMapper;
import org.springframework.transaction.annotation.Transactional;

class OrderTransaction<T> {
    private final MongoMapper<T> orders;
    private final java.util.function.Consumer<T> insertMongoAudit;
    OrderTransaction(MongoMapper<T> orders, java.util.function.Consumer<T> insertMongoAudit) {
        this.orders = orders;
        this.insertMongoAudit = insertMongoAudit;
    }
    @Transactional(transactionManager = "mongoPlusTransactionalManager", rollbackFor = Exception.class)
    public void place(T order) {
        if (!orders.save(order)) throw new IllegalStateException("Order write failed");
        insertMongoAudit.accept(order);
    }
}
