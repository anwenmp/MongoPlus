package skillcheck.c62;
import com.mongoplus.sharding.DataSourceShardingStrategy;
import com.mongoplus.enums.ExecuteMethodEnum;

class ArchiveRouting implements DataSourceShardingStrategy {
    public String sharding(String current, ExecuteMethodEnum method, Object[] source) {
        return current;
    }
}
