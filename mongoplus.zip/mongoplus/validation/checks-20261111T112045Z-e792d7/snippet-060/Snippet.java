package skillcheck.c60;
import com.mongoplus.aggregate.AggregateWrapper;
import org.bson.Document;
import java.util.Arrays;

class SemanticLookup {
    static AggregateWrapper pipeline() {
        Document body = new Document("index", "catalog_vec")
            .append("path", "embedding").append("queryVector", Arrays.asList(0.1,0.2,0.3))
            .append("numCandidates", 30).append("limit", 3);
        return new AggregateWrapper().custom(new Document("$vectorSearch", body));
    }
}
