package skillcheck.c67;
import com.mongoplus.conditions.query.QueryWrapper;
import com.mongoplus.conditions.update.UpdateWrapper;
import org.bson.Document;

class RemoveQualifiedItems {
    static UpdateWrapper<Object> byField() {
        Document element = new Document("sku","X").append("qty",new Document("$gte",2));
        return new UpdateWrapper<Object>().eq("_id",2).pull("items",element);
    }
    static UpdateWrapper<Object> byWrapper() {
        Document element = new Document("sku","X").append("qty",new Document("$gte",2));
        QueryWrapper<Object> body = new QueryWrapper<Object>().custom(new Document("items",element));
        return new UpdateWrapper<Object>().eq("_id",2).pull(body);
    }
}
