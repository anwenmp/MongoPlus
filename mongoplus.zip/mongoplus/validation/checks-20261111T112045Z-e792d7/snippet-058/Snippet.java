package skillcheck.c58;
import com.mongoplus.cache.global.HandlerCache;
import com.mongoplus.handlers.read.FieldBindHandler;

class BindStatusNames {
    static void register() {
        HandlerCache.addReadHandler(new FieldBindHandler((binding,source,target) -> {
            if ("status".equals(binding.type())) target.setValue("Name-"+source);
        }));
    }
}
