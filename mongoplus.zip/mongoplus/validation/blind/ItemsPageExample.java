import com.mongoplus.annotation.ID;
import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.conditions.query.QueryWrapper;
import com.mongoplus.mapper.MongoMapper;
import com.mongoplus.model.PageResult;
import java.util.List;

public final class ItemsPageExample {
    @CollectionName("blind_orders")
    public static class Order {
        @ID public String id;
        public List<Item> items;
    }

    public static class Item {
        public String sku;
        public Integer qty;
    }

    public static PageResult<Order> page(MongoMapper<Order> orders,
                                         String sku, int minimumQty,
                                         int pageNum, int pageSize) {
        if (pageNum < 1 || pageSize < 1) {
            throw new IllegalArgumentException("pageNum and pageSize must be positive");
        }
        QueryWrapper<Object> item = new QueryWrapper<Object>()
            .eq("sku", sku).gte("qty", minimumQty);
        QueryWrapper<Order> filter = new QueryWrapper<Order>()
            .elemMatch("items", item).orderByAsc("_id");
        return orders.page(filter, pageNum, pageSize);
    }
}
