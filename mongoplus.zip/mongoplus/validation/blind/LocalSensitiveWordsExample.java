import com.mongoplus.annotation.SensitiveWord;
import com.mongoplus.enums.SensitiveType;
import com.mongoplus.manager.SensitiveWordManager;
import com.mongoplus.property.SensitiveWordProperty;

public final class LocalSensitiveWordsExample {
    public static class Message {
        @SensitiveWord public String body;
    }

    // Keep this manager for the process lifetime; do not construct it per request.
    public static SensitiveWordManager initialize() {
        SensitiveWordProperty property = new SensitiveWordProperty();
        property.setSensitiveType(SensitiveType.LOCAL);
        SensitiveWordManager manager = new SensitiveWordManager(property);
        manager.addWordBlacklist("blocked-demo-word");
        return manager;
    }

    public static void allowAtRuntime(SensitiveWordManager manager, String allowedWord) {
        manager.addSensitiveWordAllow(allowedWord);
    }

    public static void validateExplicitly(SensitiveWordManager manager, String input) {
        manager.handler(input);
    }
}
