import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.comm.FieldEncrypt;
import com.mongoplus.enums.AlgorithmEnum;
import com.mongoplus.handlers.FieldHandler;
import com.mongoplus.handlers.FieldHandlerChain;
import com.mongoplus.mapping.FieldInformation;
import java.util.Arrays;
import java.util.function.Function;

public final class FieldPipelineExample {
    @CollectionName("blind_secrets")
    public static class SecuredRecord {
        // Supply the AES key through the application's mongo-plus.encryptor.key configuration.
        @FieldEncrypt(algorithm = AlgorithmEnum.AES)
        public String secret;
    }

    private abstract static class SecretHandler implements FieldHandler {
        @Override public Function<FieldInformation, Boolean> activate() {
            return f -> f.getBelongClass() == SecuredRecord.class
                && "secret".equals(f.getName());
        }

        // The single-argument method remains an abstract member of the documented interface.
        @Override public Object handler(FieldInformation f) {
            return handler(f, f.getValue());
        }
    }

    private static final class Trim extends SecretHandler {
        @Override public Integer order() { return 10; }
        @Override public Object handler(FieldInformation f, Object currentValue) {
            return currentValue instanceof String ? ((String) currentValue).trim() : null;
        }
    }

    private static final class AddPrefix extends SecretHandler {
        @Override public Integer order() { return 20; }
        @Override public Object handler(FieldInformation f, Object currentValue) {
            return currentValue instanceof String ? "normalized:" + currentValue : null;
        }
    }

    // Call once at process startup, before any entity writes.
    public static void register() {
        FieldHandlerChain.getInstance().registerAll(
            Arrays.<FieldHandler>asList(new Trim(), new AddPrefix()));
    }
}
