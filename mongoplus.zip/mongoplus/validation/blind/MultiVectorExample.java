import com.mongoplus.annotation.collection.CollectionField;
import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.index.vector.MongoVectorField;
import com.mongoplus.annotation.index.vector.MongoVectorFields;
import com.mongoplus.annotation.index.vector.MongoVectorIndex;
import com.mongoplus.annotation.index.vector.MongoVectorIndexes;
import com.mongoplus.enums.SearchVectorSimilarity;
import com.mongoplus.enums.VectorFieldType;
import com.mongoplus.manager.MongoPlusClient;
import com.mongoplus.toolkit.AutoUtil;
import java.util.Collections;
import java.util.List;

public final class MultiVectorExample {
    @CollectionName("blind_vectors")
    @MongoVectorIndexes({
        @MongoVectorIndex(name = "vec_cosine", fields = {
            @MongoVectorField(fieldName = "$tenantId", type = VectorFieldType.FILTER)
        }),
        @MongoVectorIndex(name = "vec_dot", fields = {
            @MongoVectorField(fieldName = "$tenantId", type = VectorFieldType.FILTER)
        })
    })
    public static class Product {
        @CollectionField("tenant_id") public String tenantId;

        @MongoVectorFields({
            @MongoVectorField(name = "vec_cosine", numDimensions = 3,
                similarity = SearchVectorSimilarity.COSINE),
            @MongoVectorField(name = "vec_dot", numDimensions = 3,
                similarity = SearchVectorSimilarity.DOT_PRODUCT)
        })
        public List<Double> embedding;
    }

    // This invokes remote DDL. The blind evaluation does not call this method.
    public static void createIndexes(MongoPlusClient client) {
        AutoUtil.autoCreateIndexes(Collections.<Class<?>>singletonList(Product.class), client);
    }
}
