# MongoPlus Skill 独立盲测评估

日期：2026-11-11。

## 评估边界与结论

入口只使用 `mongoplus/SKILL.md`，随后沿其链接读取本 Skill 的专题、注解、API 签名与公开类型文档。未读取框架源码、旧 Skill、`audit/coverage-report.md`、已有 validation 评估；未安装依赖或连接数据库。为补齐 `HandlerCache` 的 import，读取了 Skill 链接的 `audit/public-types.md` 对应行。没有把文档内的历史运行结论算成本次执行结果。

本次生成六个 Java 示例。**编译 NOT_RUN、数据库执行 NOT_RUN**：本盲测未读取项目 POM/JAR、构建目录或已有验证环境，因此不宣称已编译通过；示例使用的公开类型与方法来自本文记录的文档。主评估者可在其独立验证环境编译这些文件。

| 需求 | 仅靠新 Skill 的完成度 | 状态 |
|---|---|---|
| MongoMapper 同一 items 元素筛选并分页 | 可定位正确公开入口、重载和完整示例 | DOC_RESOLVED；运行 UNVERIFIED |
| 一个字段两个独立 Vector 索引并含 tenant filter | 容器、所属索引名、物理路径转换和注册均可定位 | DOC_RESOLVED；部署/运行 UNVERIFIED |
| 两个写处理器串联后内置加密 | 可定位双参数 currentValue、顺序及注册入口 | DOC_RESOLVED；组合运行 UNVERIFIED |
| replaceRoot 完整阶段与 Document 表达式 | 可明确区分 Java 重载选择和 BSON 包装 | DOC_RESOLVED；运行 UNVERIFIED |
| 非 Spring LOCAL 敏感词与动态白名单 | 有直接启动配方与精确管理 API | DOC_RESOLVED；并发更新等 UNVERIFIED |
| FieldBind 字典回填与 Boot4 注册 | 能定位注解、ReadHandler 和 Boot4 差异；不足以独立确认完整回调实现 | PARTIAL；命名 CONTRACT_UNRESOLVED；注册精确签名 UNVERIFIED |

`DOC_RESOLVED` 仅表示文档足以作 API 选择，不表示已核对当前源码或实际运行。

## 1. 从 MongoMapper<Order> 查询同一 items 元素并分页

### 文档导航链

`SKILL.md` → [查询专题](../../references/query.md) 的“同一明细”与分页说明 → [查询 API / ElemMatch](../../references/api/query.md)；`SKILL.md` → [CRUD](../../references/crud.md) 的声明类型对照 → [访问 API / MongoMapper](../../references/api/data-access.md)。

### API、import 与实际声明

完整示例：[ItemsPageExample.java](ItemsPageExample.java)。核心 import 是：

```java
import com.mongoplus.conditions.query.QueryWrapper;
import com.mongoplus.mapper.MongoMapper;
import com.mongoplus.model.PageResult;
```

文档列出的实际相关声明：

```java
// ElemMatch<T, Children>
default Children elemMatch(String column, Wrapper<?> queryWrapper);
default Children elemMatch(boolean condition, String column, Wrapper<?> queryWrapper);
default Children elemMatch(SFunction<T, Object> column, Wrapper<?> queryWrapper);
default Children elemMatch(boolean condition, SFunction<T, Object> column, Wrapper<?> queryWrapper);

// MongoMapper<T>，不是非泛型 BaseMapper 的显式实体类型重载
PageResult<T> page(Wrapper<T> queryWrapper, Integer pageNum, Integer pageSize);
<R> PageResult<R> page(Wrapper<T> queryWrapper, Integer pageNum, Integer pageSize, Class<R> rClazz);
<R> List<R> pageList(Wrapper<T> queryWrapper, Integer pageNum, Integer pageSize, Class<R> rClazz);
```

`Wrapper` 的包为 `com.mongoplus.conditions.Wrapper`；`SFunction` 的包为 `com.mongoplus.support.SFunction`。示例不直接声明这两类变量，故无需导入。

### 代码与边界

```java
QueryWrapper<Object> item = new QueryWrapper<Object>()
    .eq("sku", sku).gte("qty", minimumQty);
QueryWrapper<Order> filter = new QueryWrapper<Order>()
    .elemMatch("items", item).orderByAsc("_id");
return orders.page(filter, pageNum, pageSize);
```

这表达的是 `items: {$elemMatch: {sku: ..., qty: {$gte: ...}}}`。不能改写成两个独立点路径比较：`items.sku` 与 `items.qty` 可能分别命中不同元素。嵌套层内部路径从 Item 起算，使用库内字段名 `sku`、`qty`。当前页从 1 开始，示例在调用前检查页号与页大小正数；稳定排序使用唯一 `_id`。每次新建 Wrapper。

既有 `MongoMapper<Order>` 可以直接调用，不需要转为 Repository 或伪造 `BaseMapper<Order>`。若应用尚未注册 Mapper，应按集成页使用 `@Mongo` 与 `@MongoMapperScan`；本题传入的是已存在的 typed Mapper，不额外创建连接或代理。

需实际验证的反例为：一个 items 元素 sku 正确但 qty 不足，另一个 qty 足够但 sku 不同；该订单应不匹配。真实 filter、分页总数、页边界与完整结果集本次均 **UNVERIFIED / NOT_RUN**。

## 2. 同一个 Java 字段配置两个独立 Vector Search 索引，含 tenant filter

### 文档导航链

`SKILL.md` → [Search/Vector 专题](../../references/search-vector.md) → [注解目录](../../annotations/index.md) → [Vector 注解](../../annotations/vector.md) 的 `MongoVectorFields`、`MongoVectorIndexes`、`MongoVectorField`、`MongoVectorIndex` → [管理 API / AutoUtil](../../references/api/management.md) 与 [辅助 API / SearchVectorSimilarity](../../references/api/utilities.md)。自动创建开关与扫描配置由 [普通索引](../../references/indexes.md) 和 [配置](../../references/configuration.md) 补齐。

### API、import 与实际声明

完整 import 和声明见 [MultiVectorExample.java](MultiVectorExample.java)。核心公开类型为：

```java
import com.mongoplus.annotation.index.vector.MongoVectorField;
import com.mongoplus.annotation.index.vector.MongoVectorFields;
import com.mongoplus.annotation.index.vector.MongoVectorIndex;
import com.mongoplus.annotation.index.vector.MongoVectorIndexes;
import com.mongoplus.enums.SearchVectorSimilarity;
import com.mongoplus.enums.VectorFieldType;
import com.mongoplus.manager.MongoPlusClient;
import com.mongoplus.toolkit.AutoUtil;
```

注解表给出：

- `MongoVectorIndex` 与 `MongoVectorIndexes` 作用于 TYPE；前者可重复，后者 `value` 是必填 `MongoVectorIndex[]`。
- `MongoVectorField` 与 `MongoVectorFields` 作用于 FIELD / ANNOTATION_TYPE；前者可重复，后者 `value` 是必填 `MongoVectorField[]`。
- 字段级 `MongoVectorField.name` 在多个类级索引时必须明确指定所属索引；`fieldName=""` 自动使用该字段的映射名称。
- 类级 `MongoVectorIndex.fields` 中每个成员的 `fieldName` 必填、`name` 必须留空；它们与对应字段级注解合并。
- `numDimensions` 默认 -1，vector 必填且范围 1..8192；`similarity` 默认 DEFAULT，vector 必填。`VectorFieldType.FILTER` 不能填写 vector 选项。

实际手工注册方法的文档声明：

```java
public static void autoCreateIndexes(Collection<Class<?>> classCollection,
                                     MongoPlusClient mongoPlusClient);
```

### 代码与边界

示例在 `embedding` 上使用 `@MongoVectorFields`，分别明确 `name="vec_cosine"` 与 `name="vec_dot"`。两者维度均为 3，分别使用文档枚举中已确认的 COSINE / DOT_PRODUCT。两个类级索引都独立包含：

```java
@MongoVectorField(fieldName = "$tenantId", type = VectorFieldType.FILTER)
```

Java 字段 `tenantId` 显式 `@CollectionField("tenant_id")`。根据注解表，带 `$` 的属性路径按实体映射转换，因此预期两个索引的 filter 路径均为 `tenant_id`；若直接写 `fieldName="tenantId"`，文档说它是 MongoDB 物理路径，不能期望自动别名转换。`$tenantId` 在此是索引声明的属性映射语法，不是查询表达式值。

注册二选一：在 Boot 对 Product 所在包配置 `mongo-plus.configuration.auto-scan-packages`，并启用默认关闭的 `mongo-plus.configuration.auto-create-index`；或显式调用示例中的 `AutoUtil.autoCreateIndexes(...)`。注解存在不等于远端已创建、已 READY 或可查询。

这是独立 `type=vectorSearch` 索引，不能改成 Search 的 VECTOR 字段声明。Search / Vector 共享名称空间；两个索引必须各有自己的 vector 字段，不能认为容器自动跨索引继承字段或选项。filter 路径被索引只表示可用于筛选，查询仍需在 `$vectorSearch.filter` 中传入当前租户约束，不能把索引声明当作租户数据隔离策略。

部署必须支持这些 Vector 功能，并等待索引就绪；自动创建不修复同名冲突，不承诺跨索引 DDL 原子性。此示例只声明向量维度，框架不生成 embedding。实际 `createSearchIndexes/listSearchIndexes` 命令、路径解析、tenant 查询结果均 **UNVERIFIED / NOT_RUN**。

## 3. 两个自定义字段处理器串联，然后进入内置加密

### 文档导航链

`SKILL.md` → [扩展体系](../../references/extensions.md) 的 currentValue 与 order 段落 → [扩展 API / FieldHandler 和 FieldHandlerChain](../../references/api/extensions.md) → [字段处理](../../references/field-security.md) → [注解目录](../../annotations/index.md) → [FieldEncrypt](../../annotations/field-processing.md#fieldencrypt)。加密全局密钥由 [配置](../../references/configuration.md) 的 `MongoEncryptorProperty` 补齐。

### API、import 与实际声明

完整代码见 [FieldPipelineExample.java](FieldPipelineExample.java)，包含以下真实 import：

```java
import com.mongoplus.handlers.FieldHandler;
import com.mongoplus.handlers.FieldHandlerChain;
import com.mongoplus.mapping.FieldInformation;
import com.mongoplus.annotation.comm.FieldEncrypt;
import com.mongoplus.enums.AlgorithmEnum;
import java.util.function.Function;
```

文档实际声明：

```java
default Integer order();
default Function<FieldInformation, Boolean> activate();
@Deprecated Object handler(FieldInformation fieldInformation);
default Object handler(FieldInformation fieldInformation, Object currentValue);

public static FieldHandlerChain getInstance();
public void register(FieldHandler fieldHandler);
public void registerAll(Collection<? extends FieldHandler> fieldHandlers);
```

### 代码与边界

示例只激活 `SecuredRecord.secret`，两个节点 order 分别为 10、20；双参数实现只处理传入的 `currentValue`。单参数方法仍按接口抽象声明实现，作为兼容入口，不能只实现双参数方法而漏掉它。

```java
FieldHandlerChain.getInstance().registerAll(
    Arrays.<FieldHandler>asList(new Trim(), new AddPrefix()));
```

实体字段声明 `@FieldEncrypt(algorithm = AlgorithmEnum.AES)`，应用通过 `mongo-plus.encryptor.key` 配置密钥；本例不把演示密钥写入代码。默认 EncryptFieldHandler 已在默认链中，不手动重复注册。

文档给出的预期顺序为 LOCAL 敏感词 MIN_VALUE（若安装）→ TypeHandler 0 → Trim 10 → AddPrefix 20 → EncryptFieldHandler MAX_VALUE-1 → DBRef MAX_VALUE。前序返回值经最新 currentValue 交给下一节点；返回 null 表示“不替换当前值”，不表示把字段写为 null。例如 `" hello "` 先得到 `"hello"`，再得到 `"normalized:hello"`，最后才进入 AES。默认 BASE64 不提供保密性，故此需求明确选 AES。

应在启动阶段注册一次。FieldHandler 不能仅声明成任意容器 Bean 后期待自动生效；静态链可能跨上下文累积，相同 order 也不保证跨容器稳定次序。应走实体 save / 实体 update 转换路径；wrapper-only、直接 BSON、原始 bulk / Driver 不保证经过同一处理链。加密、解密与查询条件转换是不同入口。

AES 实际密文、回读、null/异常、批量及 TypeHandler 组合本次 **UNVERIFIED / NOT_RUN**。

## 4. replaceRoot 的完整阶段与 Document 表达式如何选择重载

### 文档导航链

`SKILL.md` 的“同名 Bson 重载”提示 → [聚合专题](../../references/aggregation.md) 的阶段包装表及 Java 重载解析提示 → [聚合 API / Aggregate 和 LambdaAggregateWrapper](../../references/api/aggregation.md) → [访问 API / MongoMapper.list](../../references/api/data-access.md)。

### API、import 与实际声明

完整代码见 [ReplaceRootExample.java](ReplaceRootExample.java)：

```java
import com.mongoplus.aggregate.AggregateWrapper;
import com.mongoplus.mapper.MongoMapper;
import java.util.List;
import org.bson.Document;
import org.bson.conversions.Bson;
```

文档实际声明同时包含：

```java
<TExpression> Children replaceRoot(final TExpression fieldName);
Children replaceRoot(final Document value);
<T> Children replaceRoot(final SFunction<T, ?> fieldName);
Children replaceRoot(final Bson bson);
// 执行：
<R> List<R> list(Aggregate<?> aggregate, Class<R> rClass);
```

### 代码与边界

完整阶段明确选择 Bson 重载，原样追加：

```java
Document stage = new Document("$replaceRoot", new Document("newRoot", "$customer"));
AggregateWrapper pipeline = new AggregateWrapper().replaceRoot((Bson) stage);
```

Document 表达式选择更具体的 Document 重载，由框架包装阶段：

```java
Document expression = new Document("orderId", "$_id").append("customer", "$customer");
AggregateWrapper pipeline = new AggregateWrapper().replaceRoot(expression);
```

对应预期 pipeline 分别是：

```javascript
[{ $replaceRoot: { newRoot: "$customer" } }]
[{ $replaceRoot: { newRoot: { orderId: "$_id", customer: "$customer" } } }]
```

Document 实现 Bson 不意味着 Java 调用选择 Bson 重载；省略强制转换会先选择 Document 表达式重载。把完整阶段直接作为 Document 传入会导致多包一层。反过来，将内部 Document 表达式强制转为 Bson 会把它当完整阶段追加。`custom(Bson)` 也是完整阶段入口，但当前已有合法 replaceRoot 重载，无需转向 Driver。

字符串中的 `$customer`、`$_id` 是字段引用；普通 Document 是构造新根文档的表达式，不是 JSON 字符串。第一个示例要求 customer 的实际值为文档；缺失或非文档值等服务端边界需运行验证。结果形状已变化，应使用 Document / 对应 DTO 接收。

本次未执行任一重载；完整实际 pipeline、服务端接受性与原生 aggregate 结果比较均 **UNVERIFIED / NOT_RUN**。专题还提示 replaceWith 有同样的 Document / Bson 重载差别，不能从其他聚合方法名推断包装语义。

## 5. 无 Spring 初始化 LOCAL 敏感词并运行时加白名单

### 文档导航链

`SKILL.md` → [敏感词专题](../../references/sensitive-word.md) 的独立 Core 初始化配方 → [注解目录](../../annotations/index.md) → [SensitiveWord 注解](../../annotations/field-processing.md#sensitiveword) → [可选模块 API / SensitiveWordManager、SensitiveWordProperty](../../references/api/optional-modules.md)。默认配置字段由 [配置](../../references/configuration.md) 补齐。

### API、import 与实际声明

完整代码见 [LocalSensitiveWordsExample.java](LocalSensitiveWordsExample.java)。import：

```java
import com.mongoplus.annotation.SensitiveWord;
import com.mongoplus.enums.SensitiveType;
import com.mongoplus.manager.SensitiveWordManager;
import com.mongoplus.property.SensitiveWordProperty;
```

不能误导入 `com.mongoplus.annotation.comm.SensitiveWord`。必须有 `mongo-plus-sensitive-word` 与 Core；可选模块的 Core 依赖为 provided，不能只引入可选模块而忽略 Core 的运行依赖。只有 Core 的配置属性不代表词库已经初始化。

文档实际声明包括：

```java
public SensitiveWordManager(SensitiveWordProperty sensitiveWordProperty);
public SensitiveWordManager(@Nullable SensitiveWordBs sensitiveWordBs,
                            SensitiveWordProperty sensitiveWordProperty);
public SensitiveWordManager(SensitiveWordConfigurationProperty property, LoadExtraWord loadExtraWord);
public void addWordBlacklist(String... words);
public void addWordBlacklist(Collection<String> words);
public void addWordBlackList(Path wordFile);
public void addSensitiveWordAllow(String... words);
public void addSensitiveWordAllow(Collection<String> words);
public void addSensitiveWordAllow(Path wordFile);
public void handler(String target);
public String replace(String word);
```

`Blacklist` 的字符串/集合拼写与 `BlackList(Path)` 的文件重载拼写不同，不统一改名。示例使用 String 可变参数重载。

### 代码与边界

```java
SensitiveWordProperty property = new SensitiveWordProperty();
property.setSensitiveType(SensitiveType.LOCAL);
SensitiveWordManager manager = new SensitiveWordManager(property);
manager.addWordBlacklist("blocked-demo-word");
// 同一个 Manager 在进程运行时：
manager.addSensitiveWordAllow(allowedWord);
```

文档明确说明构造器构建词库、登记 Manager 到 HandlerRegistry 并初始化 LOCAL/GLOBAL 节点，故不再手动调用 `initSensitiveType()`，也不重复创建 SensitiveWordFieldHandler。选定字段标 `@SensitiveWord`，随后经实体写转换处理；若只要显式验证文本，可调用 manager.handler(input)，无需连接数据库。

LOCAL Handler 命中时拒绝，返回 null 不等于回写掩码；`handler` 命中抛 SensitiveWordException，`replace` 才返回替换后的字符串。不能凭 `ResultHandler.MASK` 的公开枚举就宣称字段链会掩码保存。GLOBAL 是拦截器路径，与 LOCAL 注解字段不同。

启动后持有同一个 Manager，运行时只更改词库；避免每个请求重建全局静态链。ignoreCase/Width 等默认行为可能影响词语匹配；`ignoreChar` 字段虽存在，文档说当前固定使用 specialChars 忽略器，不能假定它已控制实际行为。

管理方法是明确现成 API，但白名单覆盖黑名单的全部组合、词库重建成本、并发更新与 wrapper/raw BSON 路径本次 **UNVERIFIED / NOT_RUN**。`setSensitiveType` 可在专题配方找到，API 签名页未列出该继承配置模型的生成访问器；这不会支持进一步猜测其余未列出的配置方法。

## 6. 字典翻译回填另一个字段，Boot4 注册与命名限制

### 文档导航链

`SKILL.md` → [映射专题](../../references/mapping.md) 的字典回写 → [注解目录](../../annotations/index.md) → [FieldBind 注解](../../annotations/mapping.md#fieldbind) → [映射 API / DataBindHandler、FieldBindHandler](../../references/api/mapping.md) → [扩展体系](../../references/extensions.md) → [集成页](../../references/integration.md) 的 Boot3/Boot4 ReadHandler 接线差异。为补齐 HandlerCache 包名，按扩展页链接读取了 [公开类型矩阵](../../audit/public-types.md) 的 HandlerCache 项。

### API、import 与实际声明

声明与注册形状见 [Boot4FieldBindExample.java](Boot4FieldBindExample.java)：

```java
import com.mongoplus.annotation.collection.CollectionField;
import com.mongoplus.annotation.collection.FieldBind;
import com.mongoplus.cache.global.HandlerCache;
import com.mongoplus.handlers.DataBindHandler;
import com.mongoplus.handlers.read.FieldBindHandler;
```

注解 `@FieldBind` 作用于 FIELD，`type`、`target` 都是必填 String；`type` 为业务字典标识，`target` 指回填目标。实际声明：

```java
void setMetaObject(FieldBind fieldBind, Object fieldValue, FieldInformation fieldInformation);
public FieldBindHandler(DataBindHandler dataBindHandler);
@Override public Function<FieldInformation, Boolean> activate();
@Override public Object read(FieldInformation fieldInformation, Object source);
```

### 能由文档安全确认的声明与接线

```java
@FieldBind(type = "order_status", target = "label")
public String status;
@CollectionField(exist = false)
public String label;

// dictionary 为应用已经正确实现的 DataBindHandler。
HandlerCache.addReadHandler(new FieldBindHandler(dictionary));
```

Boot4 需用 `mongo-plus-boot4-starter`，不能与包名重叠的 Boot3 Starter 同时引入。Boot3 的自动配置收集 ReadHandler Bean；文档明确说 Boot4 当前没有这一步。因此只声明 FieldBindHandler 为 Bean 不足以保证生效，应从应用启动初始化中显式调用上述注册，在首次读取前完成，且只做一次。FieldBindHandler 不是默认读取节点。仅声明 DataBindHandler Bean 或只在字段写注解也不足。

目标字段必须在实体中实际存在；展示字段不想入库时使用 `@CollectionField(exist=false)`。`target` 不能直接被描述为“任意 Java 属性名都支持”。注解文档报告默认命名配置下 `target="statusName"` 出现 target field not found，保留 `CONTRACT_UNRESOLVED`，而示例使用文档报告已实测的单词目标 `label`。本评估没有复现该运行现象，不能据此把所有驼峰目标或别名规则都归纳成已确认的框架缺陷或正式限制。

### 本题无法独立闭合之处

1. **HandlerCache.addReadHandler 精确签名缺失：UNVERIFIED。** 专题与集成页给出方法名；公开类型矩阵给出准确包名。但 API 各族没有 HandlerCache 节，也没有 addReadHandler 的参数类型、重载和返回值。因此示例注册行遵循文档配方，不能声称已核验实际声明或编译。
2. **字典回调参数角色不完整：CONTRACT_UNRESOLVED。** 签名只给 `FieldInformation fieldInformation`；专题没有解释它是源 status 元数据还是目标 label 元数据，也未给 setMetaObject 的完整回调示例。由名称推测后直接调用 `fieldInformation.setValue(label)` 可能误写源字段；本盲测不这样猜测。因此示例接收外部已实现的 DataBindHandler，未提供未经确认的回调体。这意味着仅凭当前文档尚不能独立完成本题的“字典值真正回填 label”部分。
3. Boot4 启动生命周期、注册前后回读与命名配置矩阵本次 **NOT_RUN**。不能用上述注册形状作为当前 Boot4 应用已生效的证明。

## 文档可改进点

优先补全 `HandlerCache` 的公开方法签名与最小启动注册示例，并明确 `DataBindHandler.setMetaObject` 每个参数的角色、目标赋值方式及可工作的完整字典样例。这样第六题可以在不读取框架源码的约束下闭合。

`FieldBind.target` 命名差异已经被显式保留为 CONTRACT_UNRESOLVED，这比给出未经验证的通用规则可靠；后续若完成运行研究，应补充 Java 字段名、物理别名、驼峰转换开关与 target 值的对照表。

其余五题的专题能提供操作选择、具体签名与边界，尤其完整阶段/表达式重载、同字段多索引归属、currentValue 串联和 LOCAL 自动安装说明，均能避免常见的无源码猜测。
