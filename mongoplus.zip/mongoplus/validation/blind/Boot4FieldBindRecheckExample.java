import com.mongoplus.annotation.collection.CollectionField;
import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.collection.FieldBind;
import com.mongoplus.cache.global.HandlerCache;
import com.mongoplus.handlers.DataBindHandler;
import com.mongoplus.handlers.read.FieldBindHandler;

public final class Boot4FieldBindRecheckExample {
    @CollectionName("blind_status_orders")
    public static class Order {
        @FieldBind(type = "order_status", target = "label")
        public String status;

        @CollectionField(exist = false)
        public String label;
    }

    // Invoke once from the existing application's startup lifecycle, before entity reads.
    public static void registerBeforeFirstRead() {
        DataBindHandler dictionary = (binding, source, target) -> {
            if (!"order_status".equals(binding.type())) {
                return;
            }
            String label;
            if ("PAID".equals(source)) {
                label = "已支付";
            } else if ("NEW".equals(source)) {
                label = "待支付";
            } else {
                label = "未知状态";
            }
            target.setValue(label);
        };
        HandlerCache.addReadHandler(new FieldBindHandler(dictionary));
    }
}
