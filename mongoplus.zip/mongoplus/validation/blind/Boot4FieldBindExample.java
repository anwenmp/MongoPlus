import com.mongoplus.annotation.collection.CollectionField;
import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.collection.FieldBind;
import com.mongoplus.cache.global.HandlerCache;
import com.mongoplus.handlers.DataBindHandler;
import com.mongoplus.handlers.read.FieldBindHandler;

public final class Boot4FieldBindExample {
    @CollectionName("blind_status_orders")
    public static class Order {
        @FieldBind(type = "order_status", target = "label")
        public String status;

        @CollectionField(exist = false)
        public String label;
    }

    // Documentation recipe only: addReadHandler's exact declaration is absent from API pages.
    // Call exactly once from application startup, before the first MongoPlus entity read.
    // The callback implementation is intentionally supplied by the caller: the documentation
    // does not define whether its FieldInformation argument represents the source or target.
    public static void registerBeforeFirstRead(DataBindHandler dictionary) {
        HandlerCache.addReadHandler(new FieldBindHandler(dictionary));
    }
}
