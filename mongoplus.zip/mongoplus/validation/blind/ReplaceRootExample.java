import com.mongoplus.aggregate.AggregateWrapper;
import com.mongoplus.mapper.MongoMapper;
import java.util.List;
import org.bson.Document;
import org.bson.conversions.Bson;

public final class ReplaceRootExample {
    public static AggregateWrapper fullStage() {
        Document stage = new Document("$replaceRoot", new Document("newRoot", "$customer"));
        return new AggregateWrapper().replaceRoot((Bson) stage);
    }

    public static AggregateWrapper documentExpression() {
        Document expression = new Document("orderId", "$_id").append("customer", "$customer");
        return new AggregateWrapper().replaceRoot(expression);
    }

    public static <T> List<Document> run(MongoMapper<T> orders, AggregateWrapper pipeline) {
        return orders.list(pipeline, Document.class);
    }
}
