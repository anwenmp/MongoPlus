# 第六题文档更新后复查

日期：2026-11-11。首次发现完整保留在 [evaluation.md](evaluation.md)，此文件不替换它。复查只重新从当前 `SKILL.md` 导航第六题；未读框架源码、旧 Skill、覆盖报告或其他 validation 文件，未编译、安装或连接数据库。

## 结论

当前文档已补齐首次发现的两个缺口：可以仅靠新 Skill 确认 `HandlerCache.addReadHandler` 的精确声明，并实现 DataBindHandler 将源业务值翻译后写入目标字段。第六题的 API 选择与代码构造现可记为 **DOC_RESOLVED**。运行和 Boot4 启动验证仍为 **UNVERIFIED / NOT_RUN**；驼峰 target 命名仍按文档保留 **CONTRACT_UNRESOLVED**。

## 本次重新走过的导航链

1. `SKILL.md` 中“字典回写” → [映射专题](../../references/mapping.md)。当前新增的 FieldBind 段明确写出回调三个参数角色，并直接给出注册与目标 setValue 示例。
2. `SKILL.md` 的注解规则 → [注解目录](../../annotations/index.md) → [FieldBind](../../annotations/mapping.md#fieldbind)。这里继续确认必填 type/target、FIELD 作用域、展示目标排除持久化、Boot4 显式注册要求和命名未解决状态。
3. 映射专题新增链接 → [扩展 API](../../references/api/extensions.md) 的 `com.mongoplus.cache.global.HandlerCache` 节，现可确认全部需要的 import 和 static 重载。
4. 映射专题 → [映射 API](../../references/api/mapping.md)，确认 DataBindHandler、FieldBindHandler 构造器与 FieldInformation.setValue。
5. `SKILL.md` → [集成](../../references/integration.md) 与 [扩展体系](../../references/extensions.md)，交叉确认 Boot4 不自动收集 ReadHandler Bean，静态缓存应只启动注册一次。

## 当前可以确认的声明与参数

```java
// com.mongoplus.cache.global.HandlerCache
public static void addReadHandler(ReadHandler readHandler);
public static void addReadHandler(List<ReadHandler> readHandlers);

// com.mongoplus.handlers.DataBindHandler
void setMetaObject(FieldBind fieldBind, Object fieldValue, FieldInformation fieldInformation);

// com.mongoplus.handlers.read.FieldBindHandler
public FieldBindHandler(DataBindHandler dataBindHandler);

// com.mongoplus.mapping.FieldInformation
void setValue(Object value);
```

映射专题现在明确：第一个参数 binding 是源字段上的 FieldBind 注解，第二参数 source 是源字段的当前读取值，第三参数 target 是根据注解 target 属性找到的**目标字段元数据**。因此调用 `target.setValue(译文)` 是文档支持的用法，不再需要猜它代表源字段还是目标字段。

## 完整示例与 Boot4 接线

新增 [Boot4FieldBindRecheckExample.java](Boot4FieldBindRecheckExample.java)，包含完整 import、实体与真实字典回调。它的 import 为：

```java
import com.mongoplus.annotation.collection.CollectionField;
import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.collection.FieldBind;
import com.mongoplus.cache.global.HandlerCache;
import com.mongoplus.handlers.DataBindHandler;
import com.mongoplus.handlers.read.FieldBindHandler;
```

核心逻辑：

```java
@FieldBind(type = "order_status", target = "label")
public String status;
@CollectionField(exist = false)
public String label;

DataBindHandler dictionary = (binding, source, target) -> {
    if ("order_status".equals(binding.type())) {
        target.setValue("PAID".equals(source) ? "已支付" : "未知状态");
    }
};
HandlerCache.addReadHandler(new FieldBindHandler(dictionary));
```

应用使用 `mongo-plus-boot4-starter`，从既有启动生命周期调用示例的 `registerBeforeFirstRead()` 一次，确保在首次 MongoPlus 实体读取前完成。不能仅声明 ReadHandler Bean 后期待 Boot4 自动收集；不能在每次请求重复注册。FieldBindHandler 本身不是默认读取链节点。直接 Driver 或原始 Document 的读取不能在此盲测中认定获得实体字典回填。

## 仍然保留的运行和命名边界

- 目标字段必须存在，展示字段使用 `@CollectionField(exist=false)` 可避免入库；示例选择简单目标名 `label`。
- 注解文档仍报告默认配置下 `target="statusName"` 出现 target field not found，并标记命名 CONTRACT_UNRESOLVED。本次没有实验，不把它扩张为“所有驼峰都不支持”或“用数据库下划线名必然可用”的契约。
- 当前文档足以写出上述代码，但本盲测未编译或启动 Boot4，故不宣称编译、注册、回读、目标赋值或任意命名组合已实际通过。Java 文件留给主评估者独立编译。
