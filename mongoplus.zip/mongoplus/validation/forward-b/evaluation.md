# Independent forward-test B

评估范围：仅从 `mongoplus/SKILL.md` 进入并阅读其相对链接下的专题、注解和API签名。未读取仓库源码、旧索引或旧Skill；未连接数据库、安装、编译或发送外部消息。以下是独立导航与选型结果，不能计作生产API运行PASS。

本轮8题均能找到相关专题。聚合阶段包装、Driver变更流边界、URI优先级及乐观锁选型能够给出明确答案。备份恢复的运行契约、Solon注解接线只能按Skill标为未闭合，不能假造已经可用的实现。全部编译与真实运行状态为NOT_RUN。

## 1. 指定归档数据源导出两集合并恢复

导航：SKILL → references/backup-gridfs.md → references/api/management.md；数据源注册补读references/transactions-routing.md。

选用 `com.mongoplus.manager.BackupManager` 与 `com.mongoplus.manager.MongoPlusClient`。可见构造器为 `BackupManager(String path, List<String> collectionNames, MongoPlusClient mongoPlusClient)`；实例方法 `void setDataSourceName(String)`、`void setLimit(Integer)`、`Map<String,String> export()`、`void imports(String path)`。先确保archive已注册，把两集合名放入构造器列表，设置数据源archive后export；接收每个集合到实际导出路径的映射。

恢复不能只凭本Skill完成可执行方案：API签名只有imports(String path)，专题未说明该path应为导出文件、目录或压缩包，目标集合从哪里获得、是否使用相同dataSourceName、已有文档覆盖/追加规则也没有闭合。不能写出虚构的imports(InputStream)重载，也不能承诺自动原子回滚。此部分为CONTRACT_UNRESOLVED；需要目标项目源码及真实临时集合实验。

限制：names非空、路径可写，默认批量1000；setCollectionNames/Str是追加；不保证跨集合一致性快照和幂等恢复。

发现：专题“恢复”行把“文件/输入流格式”列为核对点，容易暗示存在输入流API，但签名仅String。建议直接写精确重载，并明确当前未确认路径格式及目标选择规则。

## 2. Solon MongoDs / IgnoreTenant保证生效

导航：SKILL → references/integration.md → annotations/routing-isolation.md，补读references/isolation.md及references/api/management.md。

注解完整import：`com.mongoplus.annotation.datasource.MongoDs`（TYPE/METHOD，value必填，dsHandler默认Void.class）；`com.mongoplus.annotation.tenant.IgnoreTenant`（仅METHOD）。

从Skill不能保证Solon仅加注解就生效。集成专题明确：XPluginAuto绑定MongoTransactional，但创建MongoDataSourceAspect/TenantAspect Bean不等于beanInterceptorAdd已绑定。应将该组合记UNVERIFIED并核对实际Solon接线/启动测试，不把Spring代理契约照搬给Solon。

可选择显式管理入口：`com.mongoplus.manager.DataSourceManager` 的 `changeDataSource(String)`、`clearDataSource()`；`com.mongoplus.manager.TenantManager` 的 `withoutTenant(Supplier<T>)` / `withoutTenant(Runnable)`、ignore/restore方法。应在finally还原数据源；绕过租户仅限受信内部方法。TenantHandler/Interceptor本身仍须注册。嵌套上下文、异常、同线程复用和异步线程需要独立实验。

发现：API签名未保留static修饰符，单凭签名页无法判断TenantManager方法应按类还是实例调用。若文档不提供已验证的Solon显式绑定方案，应保持未确认，不能为验收臆造示例。

## 3. match体、sort完整阶段、lookup子管道、group阶段

导航：SKILL → references/aggregation.md → references/api/aggregation.md。

完整import：`com.mongoplus.aggregate.AggregateWrapper`、`com.mongodb.client.model.Variable`、`org.bson.Document`、`org.bson.conversions.Bson`，可使用`com.mongoplus.aggregate.pipeline.AggregateOperator`与`com.mongoplus.toolkit.Filters`。

按Skill选择的精确重载：

- `match(Bson)`：传参数体，如 `new Document("state","OPEN")`；框架包为$match。
- `sort(Bson)`：传完整阶段，如 `new Document("$sort", new Document("_id",1))`。若只有排序体，应改用`sortSpecification(Bson)`。
- `<TExpression> lookup(String from, List<Variable<TExpression>> letList, Aggregate<?> aggregate, String as)`：from为物理外表名；let中`new Variable<String>("buyer","$customer")`绑定外层字段；子管道使用`$$buyer`，不要导入同名MongoPlus Variable冒充Driver Variable。
- `group(Bson)`：传完整`{$group:{_id:"$customer",total:{$sum:"$fee"}}}`；或使用`group("$customer",Accumulators.sum("total","$fee"))`这一不同重载。

上述阶段组合交给MongoMapper.list(aggregate, Document.class)等真实终结入口。外层tenant过滤不自动保护lookup子管道。需要捕获完整父子pipeline并与原生aggregate比较结果；本轮未执行，NOT_RUN。

这题导航与阶段/体区分清楚，没有因同名方法推断所有Bson重载。

## 4. 两个业务写同事务，旧版本不覆盖新版本

导航：SKILL → references/transactions-routing.md + references/update.md → annotations/mapping.md#version / annotations/routing-isolation.md。

事务优先复用目标应用入口：Spring启用`mongo-plus.spring.transaction=true`，使用 `org.springframework.transaction.annotation.Transactional(transactionManager="mongoPlusTransactionalManager", rollbackFor=Exception.class)`，或独立选用 `com.mongoplus.annotation.transactional.MongoTransactional`。不要叠加两套入口。两个MongoMapper写必须通过同一受管MongoClient/session和容器代理；部署要支持事务。

并发编辑先评估 `com.mongoplus.annotation.collection.Version` 的整数版本字段及 `com.mongoplus.interceptor.business.OptimisticLockerInterceptor`。注册高级拦截器/Boot Bean，保留客户端读到的旧版本；实体更新可用 `BaseMapper.updateOne(entity, Wrapper<T>, UpdateOptions)`，示例QueryWrapper限制_id。版本插件把旧值加入filter并递增。缺版本先拒绝或启用setVersionIsNullException；冲突返回/异常需显式处理，不读最新版本后无条件重试旧内容。

若明确使用应用自己的revision，可选UpdateWrapper的_id+旧版本条件和inc+set原子CAS；不能与插件同时管理同一字段。事务保证多写提交边界，版本条件防止旧快照覆盖，两者均不能替代业务请求幂等。

独立验证应包括提交前不可见/提交后可见/回滚不存在、旧版本第二次提交失败、赢家内容与无关字段保留、同线程后续可写。未执行，NOT_RUN。

## 5. 敏感词局部字段并动态增加白名单

导航：SKILL → references/sensitive-word.md → annotations/field-processing.md#sensitiveword → references/api/optional-modules.md。

加入可选mongo-plus-sensitive-word模块；注解为 `com.mongoplus.annotation.SensitiveWord`。只标需要处理的字段，模式为 `com.mongoplus.enums.SensitiveType.LOCAL`（配置模型默认LOCAL）。初始化配置/LoadExtraWord→词库→HandlerRegistry中的Manager→initSensitiveType安装SensitiveWordFieldHandler。Boot可沿用SensitiveWordConfiguration自动装配；单独Core/Solon需显式接线，不能仅声明注解。

管理API为 `com.mongoplus.manager.SensitiveWordManager`，白名单可调用实例 `addSensitiveWordAllow(String... words)`、`addSensitiveWordAllow(Collection<String>)` 或 `addSensitiveWordAllow(Path)`；删除对应removeSensitiveWordAllow重载。可从Boot注入Manager，避免重新注册静态链。`SensitiveWordProperty.initSensitiveType()`负责模式安装，`LoadExtraWord.allow/deny`适合初始外部词库。替换/抛异常等ResultHandler策略必须明确，不能从@SensitiveWord推断。

限制：ignoreChar有声明但未控制当前specialChars忽略器；运行时词库更新的并发/重建契约未运行，UNVERIFIED。

发现：专题对独立Core/Solon接线只有顺序和签名，没有最小可执行注册示例，也没有直接给出敏感词配置绑定前缀。Boot注入用法可导航，但独立启动仍需核对源码/容器。HandlerRegistry签名缺static修饰符也影响直接照写。

## 6. TLS、连接池与URI同时设置

导航：SKILL → references/configuration.md。

配置前缀为`mongo-plus.data.mongodb`，类型 `com.mongoplus.property.MongoDBConnectProperty extends com.mongoplus.model.BaseProperty`。非空url使 `com.mongoplus.toolkit.UrlJoint.jointMongoUrl()`直接返回URI，独立host/port/TLS/池字段不会继续拼接。

因此已有URI时，应把tls、minPoolSize/maxPoolSize、超时等所需Driver选项明确放进URI并核对MongoClientSettings；不能假设Yaml独立字段覆盖URI。独立字段包括tls/ssl/tlsInsecure/tlsAllowInvalidHostnames、clientKeyStore/jks/keyPassword及池大小/等待、maxConnecting等，但属性存在不证明每个部署握手可用。TLS真实握手NOT_RUN；凭据和密钥不能出现在文档日志。

这题能够找到明确优先级及当前字段表；没有把retryWrites当成业务重试。

## 7. 未声明字段Map、DBRef、枚举存数字

导航：SKILL → references/mapping.md → annotations/mapping.md，补读references/extensions.md及references/api/mapping.md。

完整import与声明：

- `com.mongoplus.annotation.collection.ExtraFields`：标在 `Map<String,Object>` 字段。ignoredFields默认空，mapType默认LinkedHashMap.class，underlineToCamel=true。要走实体读取Converter；不承诺该Map天然可双向回写。
- `com.mongoplus.annotation.collection.DBRef`：标在引用对象字段。被引用实体有 `com.mongoplus.annotation.ID` 与可解析的 `CollectionName`；默认DBRefHandler参与写/读/条件，可能额外查询，不是级联保存或外键约束。db默认空、autoConvertObjectId=true，缺引用/循环/集合引用均UNVERIFIED。
- `com.mongoplus.annotation.comm.EnumValue`：标在枚举内部数字code字段，valueStore默认true；实体字段仍声明为枚举。默认EnumMappingStrategy/EnumConversionStrategy配合转换；未知历史值、null和数字BSON宽度独立验证。

TypeHandler、FieldHandler/ReadHandler及Document原始路径不要混用，实体/DTO、Map、wrapper-only、bulk分别验证。DBRef.db的优先级表来自源码注释；本轮不读取实现或运行，无法独立证明该优先级，应保留SOURCE_VERIFIED与运行未确认的区别。

发现：注解页有对原Javadoc的机械复述（例如TimeSeries属性说明中的`@TimeSeries("$field1")`片段并非完整合法示例）。当前单独Java代码块可用，但说明表中的例子同样会被Agent读取，建议校正文案或明确其为存在问题的原注释，不把注释当契约。

## 8. MongoDB全量增删改同步外部系统且断点恢复

导航：SKILL → references/events.md → references/driver-interop.md。

选择Driver Change Streams有充分原因：MongoPlus Listener只观察当前客户端命令，DataChangeRecorderInnerInterceptor只记录经过框架的操作，AsyncMultipleWriteInterceptor只面向MongoDB数据源镜像，没有外部sink或持久消费位点。

可从 `com.mongoplus.mapper.MongoMapper<?>.getCollection()`得到集合，使用 `com.mongodb.client.ChangeStreamIterable`、`MongoChangeStreamCursor`、`com.mongodb.client.model.changestream.ChangeStreamDocument`、`FullDocument`，位点为`org.bson.BsonDocument`。示例 `watch().fullDocument(FullDocument.UPDATE_LOOKUP)`，非空位点 `resumeAfter(checkpoint)`，返回cursor由调用方关闭。

业务必须保存初始快照/增量水位衔接、稳定主键、幂等账本与消费位点；外部库业务行+去重+位点在该库自己的同一事务落地，提交后推进内存位点。insert/replace/update做幂等upsert，delete用documentKey删除或墓碑。UPDATE_LOOKUP可能看到后续版本或缺全文；过期token、流失效、断网重连、重复投递、消费崩溃恢复要有补数和对账。不能承诺MongoDB和外部库原子同时提交。

本轮未运行任何订阅或外部sink，NOT_RUN。这题能够正确找到需要Driver的边界，没有绕过框架去重复实现其已有能力。

## 可复现的文档问题

1. API签名文件缺static/public/default等修饰符与类级泛型参数，降低“精确签名”可用性；方法参数中的简单类型名也未系统给出import，必要时只能再查源码链接。
2. 备份恢复运行契约没有闭合：imports仅String，专题未明确格式和目标/覆盖规则；不能以存在API推定完整备份恢复教程已验收。
3. 独立Core/Solon敏感词接线缺最小注册示例；LOCAL/GLOBAL说明清楚但无法仅按专题完成无容器初始化。
4. 原Javadoc中的片段示例/语义说明直接进入注解属性表，需与实际实现或命令核验区分。建议更明显标注“声明注释”与“已验证行为”，清理无效示例。

不把已明确写UNVERIFIED的能力当产品缺陷。上述内容是在测试者只拿Skill时遇到的可执行性或准确性缺口。
