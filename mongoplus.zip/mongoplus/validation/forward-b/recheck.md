# Forward-test B：更新后复查

只从当前SKILL.md导航，阅读本Skill专题和API签名，没有读取仓库源码、旧索引或数据库。只写本文件。代码依据Skill当前声明整理，本轮未编译、未运行，均为NOT_RUN；不把文档提到的其他实测自动计入本轮结果。

## 1. archive导出与恢复

导航：SKILL → references/backup-gridfs.md → references/api/management.md。

当前可确定：BackupManager.export()返回每个非空集合的ZIP文件路径，Map值可以交给唯一恢复重载`public void imports(String path)`。不存在InputStream恢复重载。

```java
import com.mongoplus.manager.BackupManager;
import com.mongoplus.manager.MongoPlusClient;
import java.util.Arrays;
import java.util.Map;

class ArchiveBackupUsage {
    static Map<String,String> exportTwo(MongoPlusClient client, String outputDirectory) {
        BackupManager manager = new BackupManager(outputDirectory,
            Arrays.asList("orders_archive", "audit_archive"), client);
        manager.setDataSourceName("archive");
        return manager.export();
    }

    static void restoreApprovedZip(MongoPlusClient client, String exportedZipPath) {
        BackupManager manager = new BackupManager(client);
        manager.setDataSourceName("archive");
        manager.imports(exportedZipPath);
    }
}
```

前置条件是archive数据源已经注册、输出目录可写，恢复目标已获准。每个导出Map值单独传给restoreApprovedZip即可表达当前API调用方式；这里没有实际执行任何恢复。

目标选择与破坏边界现已明确：imports读取entry首条information中的database和collection_name作为namespace；目标数据源使用Manager当前dataSourceName，information.data_source不用于目标选择。每次imports首个entry会直接drop集合再写入，后续entry追加；不能把它描述为无破坏合并、自动索引恢复、原子恢复或幂等回放。恢复前必须核对ZIP元信息中的namespace，不能靠构造器集合列表推断恢复目标。

文档已经补齐上一轮的输入、目标和覆盖边界。实际往返、类型保真、空批次、多entry与错误残留仍按专题标NOT_RUN。

## 2. 无Spring的LOCAL敏感词与动态白名单

导航：SKILL → references/sensitive-word.md → annotations/field-processing.md#sensitiveword → references/api/optional-modules.md。

以下代码具备当前文档给出的真实import、构造器与方法签名；需要Core及mongo-plus-sensitive-word及其运行依赖。应用启动时只初始化一次，后续复用返回的Manager。

```java
import com.mongoplus.annotation.SensitiveWord;
import com.mongoplus.enums.SensitiveType;
import com.mongoplus.manager.SensitiveWordManager;
import com.mongoplus.property.SensitiveWordProperty;

class LocalMessage {
    @SensitiveWord
    public String body;
    public String title;
}

class LocalSensitiveWordsUsage {
    static SensitiveWordManager initialize() {
        SensitiveWordProperty property = new SensitiveWordProperty();
        property.setSensitiveType(SensitiveType.LOCAL);
        SensitiveWordManager manager = new SensitiveWordManager(property);
        manager.addWordBlacklist("example-blocked-word");
        return manager;
    }

    static void allowAtRuntime(SensitiveWordManager manager, String phrase) {
        manager.addSensitiveWordAllow(phrase);
    }
}
```

当前专题明确构造器会构建词库、向HandlerRegistry注册自身并调用initSensitiveType安装LOCAL字段Handler，因此调用方不应再手工重复initSensitiveType或重复注册字段链。只有body被标注，title未被标注；仍需走框架实体写入链，不能推定原生BSON和所有wrapper更新均触发局部字段处理。

LOCAL字段Handler审核命中时抛SensitiveWordException，返回null，不将manager.replace返回值自动写回。需要掩码持久化应显式replace并保存。并发动态词库更新契约仍UNVERIFIED。本轮初始化、命中/白名单效果和编译均NOT_RUN。

上一轮缺失的独立初始化示例和Boot配置前缀已补充；Boot前缀为mongo-plus.sensitive-word，本题无Spring时使用对象API即可。

## 3. replaceRoot/replaceWith重载与静态修饰符

导航：SKILL → references/aggregation.md → references/api/aggregation.md；静态方法进一步通过references/api/management.md和optional-modules.md确认。

签名页现在明确列出以下不同重载：`replaceRoot(Document)`、`replaceRoot(Bson)`、泛型`<TExpression> replaceRoot(TExpression)`，replaceWith同样有这三类，还存在SFunction重载。

```java
import com.mongoplus.aggregate.AggregateWrapper;
import org.bson.Document;
import org.bson.conversions.Bson;

class ReplaceStageUsage {
    static AggregateWrapper rootFromCompleteStage() {
        Bson stage = new Document("$replaceRoot",
            new Document("newRoot", new Document("name", "$name")));
        return new AggregateWrapper().replaceRoot(stage);
    }

    static AggregateWrapper rootFromExpression() {
        Document expression = new Document("name", "$name");
        return new AggregateWrapper().replaceRoot(expression);
    }

    static AggregateWrapper withFromCompleteStage() {
        Bson stage = new Document("$replaceWith", new Document("name", "$name"));
        return new AggregateWrapper().replaceWith(stage);
    }

    static AggregateWrapper withFromExpression() {
        Document expression = new Document("name", "$name");
        return new AggregateWrapper().replaceWith(expression);
    }
}
```

前两种完整阶段变量的静态类型为Bson，选择Bson重载；Document变量按更具体的Document重载处理，属于表达式文档而不是直接追加完整阶段。完整Document若没有显式Bson类型/转换，会选择Document重载，可能得到多包一层的阶段。也可将完整文档显式转换为`(Bson) fullStage`。

专题里的“可能优先命中泛型表达式重载”还可以更精确：按签名清单，调用点传Document时首先可确定的是更具体的Document重载，而不是未确定的泛型重载；该重载内部如何转发，本轮不读源码，不能仅从签名断言。业务指导“完整阶段显式Bson、普通Document作表达式”已经清楚可用。

静态修饰符问题已修复。当前签名页可以查到：

- `com.mongoplus.config.Configuration`：`public static Configuration builder()`、`public static ExecutorFactory getExecutorFactory()`。
- `com.mongoplus.manager.TenantManager`：`public static <T> T withoutTenant(Supplier<T>)`、`public static void withoutTenant(Runnable)`以及ignore/restore方法。
- `com.mongoplus.registry.HandlerRegistry`：`public static <T> T get(Class<T>)`、`public static <T> void register(Class<T>, T)`。
- `com.mongoplus.property.SensitiveWordProperty`：静态双参数sensitiveWordBs及静态initSensitiveType(property)与各自实例方法分开列出。

签名页也提供类型import、类型参数和原文件import。上述重载构造与命令结果本轮全部NOT_RUN。

## 复查结论

三项均能从当前Skill找到操作与边界，上一轮“静态调用无法判断”“恢复输入/目标未知”“独立LOCAL初始化无法照写”的缺口已补齐。仍建议将replaceRoot/replaceWith的Java重载说明从“可能命中泛型”改成调用点静态类型决定的精确表述；不影响当前已给出的正确调用方式。
