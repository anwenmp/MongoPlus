import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.LoaderOptions;
import org.yaml.snakeyaml.constructor.SafeConstructor;
import java.io.*;
import java.nio.charset.StandardCharsets;
/** Real YAML parser bridge for running the unchanged creator validator without installing PyYAML. */
public class YamlFrontmatter {
    public static void main(String[] args)throws Exception {
        LoaderOptions options=new LoaderOptions();options.setAllowDuplicateKeys(false);
        Object parsed=new Yaml(new SafeConstructor(options)).load(new InputStreamReader(System.in,StandardCharsets.UTF_8));
        System.out.write(SourceInventory.json(parsed).getBytes(StandardCharsets.UTF_8));
    }
}
