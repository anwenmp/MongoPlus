package skillcheck.c60;
import com.mongoplus.manager.SensitiveWordManager;
import com.mongoplus.property.SensitiveWordProperty;
import com.mongoplus.enums.SensitiveType;

class LocalWordSetup {
    static SensitiveWordManager initialize() {
        SensitiveWordProperty property = new SensitiveWordProperty();
        property.setSensitiveType(SensitiveType.LOCAL);
        SensitiveWordManager manager = new SensitiveWordManager(property);
        manager.addWordBlacklist("example-blocked-word");
        manager.addSensitiveWordAllow("example-allowed-word");
        return manager;
    }
}
