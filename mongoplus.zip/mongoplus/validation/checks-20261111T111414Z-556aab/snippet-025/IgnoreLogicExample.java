package skillcheck.c25;
import com.mongoplus.annotation.logice.IgnoreLogic;

@IgnoreLogic public class IgnoreLogicExample { public void maintenance(){} }
