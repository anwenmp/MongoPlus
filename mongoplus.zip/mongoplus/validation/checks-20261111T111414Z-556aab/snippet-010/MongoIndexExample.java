package skillcheck.c10;
import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.index.MongoIndex;

@CollectionName("example_mongoindex") public class MongoIndexExample { @MongoIndex(name="email_unique", unique=true) String email; }
