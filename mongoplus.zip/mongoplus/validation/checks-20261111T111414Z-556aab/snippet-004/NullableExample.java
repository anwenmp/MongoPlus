package skillcheck.c4;
import com.mongoplus.annotation.comm.Nullable;

public class NullableExample { @Nullable String value; }
