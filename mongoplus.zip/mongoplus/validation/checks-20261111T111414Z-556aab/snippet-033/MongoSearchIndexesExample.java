package skillcheck.c33;
import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.index.search.MongoSearchIndex;
import com.mongoplus.annotation.index.search.MongoSearchIndexes;

@CollectionName("example_mongosearchindexes") @MongoSearchIndexes({@MongoSearchIndex(name="a",dynamic=true),@MongoSearchIndex(name="b",dynamic=true)}) public class MongoSearchIndexesExample {}
