package skillcheck.c12;
import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.index.MongoTextIndex;

@CollectionName("example_mongotextindex") @MongoTextIndex(fields={"title","body"}, name="article_text") public class MongoTextIndexExample {}
