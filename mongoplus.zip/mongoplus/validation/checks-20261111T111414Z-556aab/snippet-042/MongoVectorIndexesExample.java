package skillcheck.c42;
import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.index.vector.MongoVectorField;
import com.mongoplus.annotation.index.vector.MongoVectorIndex;
import com.mongoplus.annotation.index.vector.MongoVectorIndexes;
import com.mongoplus.enums.SearchVectorSimilarity;

@CollectionName("example_mongovectorindexes") @MongoVectorIndexes({@MongoVectorIndex(name="a",fields={@MongoVectorField(fieldName="embedding",numDimensions=3,similarity=SearchVectorSimilarity.COSINE)})}) public class MongoVectorIndexesExample {}
