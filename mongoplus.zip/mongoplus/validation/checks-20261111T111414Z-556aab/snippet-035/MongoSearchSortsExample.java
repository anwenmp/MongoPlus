package skillcheck.c35;
import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.index.search.MongoSearchField;
import com.mongoplus.annotation.index.search.MongoSearchIndex;
import com.mongoplus.annotation.index.search.MongoSearchIndexes;
import com.mongoplus.annotation.index.search.MongoSearchSort;
import com.mongoplus.annotation.index.search.MongoSearchSorts;
import com.mongoplus.enums.SearchFieldType;

@CollectionName("example_mongosearchsorts") @MongoSearchIndexes({@MongoSearchIndex(name="a",fields={@MongoSearchField(fieldName="title",type=SearchFieldType.TOKEN)}),@MongoSearchIndex(name="b",fields={@MongoSearchField(fieldName="title",type=SearchFieldType.TOKEN)})}) public class MongoSearchSortsExample { @MongoSearchSorts({@MongoSearchSort(name="a"),@MongoSearchSort(name="b")}) String title; }
