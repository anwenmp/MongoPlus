package skillcheck.c26;
import com.mongoplus.annotation.tenant.IgnoreTenant;

public class IgnoreTenantExample { @IgnoreTenant public void maintenance(){} }
