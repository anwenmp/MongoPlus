package skillcheck.c38;
import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.index.vector.MongoVectorField;
import com.mongoplus.annotation.index.vector.MongoVectorIndex;
import com.mongoplus.enums.SearchVectorSimilarity;

@CollectionName("example_mongovectorfield") @MongoVectorIndex(name="vec") public class MongoVectorFieldExample { @MongoVectorField(numDimensions=3,similarity=SearchVectorSimilarity.COSINE) java.util.List<Double> embedding; }
