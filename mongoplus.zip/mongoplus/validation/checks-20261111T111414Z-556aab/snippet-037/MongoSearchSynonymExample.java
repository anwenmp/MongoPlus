package skillcheck.c37;
import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.index.search.MongoSearchIndex;
import com.mongoplus.annotation.index.search.MongoSearchSynonym;

@CollectionName("example_mongosearchsynonym") @MongoSearchIndex(dynamic=true,synonyms={@MongoSearchSynonym(name="terms",sourceCollection="synonyms")}) public class MongoSearchSynonymExample {}
