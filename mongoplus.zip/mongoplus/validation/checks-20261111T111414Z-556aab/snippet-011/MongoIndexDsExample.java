package skillcheck.c11;
import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.index.MongoIndexDs;

@CollectionName("example_mongoindexds") @MongoIndexDs(dataSource="archive") public class MongoIndexDsExample {}
