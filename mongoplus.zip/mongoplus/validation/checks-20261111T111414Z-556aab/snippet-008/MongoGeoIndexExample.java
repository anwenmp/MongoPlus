package skillcheck.c8;
import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.index.MongoGeoIndex;
import com.mongoplus.enums.GeoType;

@CollectionName("example_mongogeoindex") public class MongoGeoIndexExample { @MongoGeoIndex(type=GeoType.SPHERE) Object location; }
