package skillcheck.c7;
import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.index.MongoCompoundIndex;
import com.mongoplus.annotation.index.MongoCompoundIndexes;

@CollectionName("example_mongocompoundindexes") @MongoCompoundIndexes({@MongoCompoundIndex("{\"a\":1}"),@MongoCompoundIndex("{\"b\":1}")}) public class MongoCompoundIndexesExample {}
