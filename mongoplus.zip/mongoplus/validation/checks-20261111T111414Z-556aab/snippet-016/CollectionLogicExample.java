package skillcheck.c16;
import com.mongoplus.annotation.collection.CollectionLogic;
import com.mongoplus.enums.LogicDataType;

public class CollectionLogicExample { @CollectionLogic(value="0", delval="1", delType=LogicDataType.INTEGER) Integer deleted; }
