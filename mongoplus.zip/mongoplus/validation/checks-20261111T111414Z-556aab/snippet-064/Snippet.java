package skillcheck.c64;
import com.mongoplus.conditions.update.UpdateWrapper;
import com.mongoplus.mapper.MongoMapper;
import com.mongoplus.repository.IRepository;

class OrderWrites {
    static <T> boolean claim(MongoMapper<T> orders, String id, String worker) {
        UpdateWrapper<T> change = new UpdateWrapper<T>()
            .eq("_id", id).eq("state", "OPEN")
            .set("state", "CLAIMED").set("worker", worker);
        return orders.getBaseMapper().updateOne(change, orders.getGenericityClass(), null);
    }

    static <T> boolean edit(IRepository<T> orders, String id, int seen, String title) {
        return orders.lambdaUpdate().eq("_id", id).eq("revision", seen)
            .set("title", title).inc("revision", 1).updateOne();
    }
}
