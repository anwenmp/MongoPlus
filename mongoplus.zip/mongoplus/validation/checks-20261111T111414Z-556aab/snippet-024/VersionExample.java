package skillcheck.c24;
import com.mongoplus.annotation.collection.Version;

public class VersionExample { @Version Integer version; }
