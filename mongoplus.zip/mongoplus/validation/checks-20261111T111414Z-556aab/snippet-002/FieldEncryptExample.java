package skillcheck.c2;
import com.mongoplus.annotation.comm.FieldEncrypt;
import com.mongoplus.enums.AlgorithmEnum;

public class FieldEncryptExample { @FieldEncrypt(algorithm=AlgorithmEnum.AES, key="0123456789abcdef") String secret; }
