package skillcheck.c9;
import com.mongoplus.annotation.collection.CollectionName;
import com.mongoplus.annotation.index.MongoHashIndex;

@CollectionName("example_mongohashindex") public class MongoHashIndexExample { @MongoHashIndex String key; }
